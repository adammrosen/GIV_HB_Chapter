# Analysis of Angrist Evans (1998) data for the Handbook chapter "Generalized Instrumental Variable Models, Methods, and Applications."
# This file can be used to reproduce the confidence intervals reported in Tables 8-9.
# Output is written to the file specified by paste("Section_8_2_2_Inference_", instrument_case, "_Instruments_edu12_dummy.txt", sep="")

rm(list=ls())

# CHANGE PATH VARIABLES TO POINT TO THE FOLDER WHERE THE SOURCE AND DATA FILES ARE STORED
replication_files_folder <- "/Users/amr93/Dropbox/GIV/Handbook/Replication Files/" # Set as approriate for local directory structure
path <- paste(replication_files_folder, "Section 8.2/", sep="")
setwd(path)

# SET INSTRUMENT CASE TO "T" TO PRODUCE RESULTS REPORTED IN SECOND COLUMN IN TABLE 9.
# SET INSTRUMENT CASE TO "SST" TO PRODUCE RESULTS REPORTED IN THIRD COLUMN IN TABLE 9.
# SET INSTRUMENT CASE TO "SS" TO PRODUCE RESULTS REPORTED IN THIRD COLUMN IN TABLE 10.

#instrument_case = "T"
#instrument_case = "SST"
instrument_case = "SS"

set.seed(987698764)

if (!require("mvtnorm")) install.packages("mvtnorm")                         
library(mvtnorm)
if (!require("nloptr")) install.packages("nloptr")
library(nloptr)
if (!require("prodlim")) install.packages("prodlim")
library(prodlim)

source("Inference_Functions_Probit_Projections_3.R")
source("CLR_Functions.R")

pums80 <- read.table("https://dataverse.harvard.edu/api/access/datafile/:persistentId?persistentId=doi:10.7910/DVN/8RYANI/HKEUEN",
                       sep="\t", header=TRUE)

######################## CREATE VARIABLES ######################################################
Y1 <- pums80$workedm
Y2 <- pums80$morekids
Z2 <- pums80$samesex
Z1matrix <- as.matrix(pums80$educm>12) # mother's education < 12
included_var_descrip <- "EDU > 12"
Z3 <- pums80$multi2nd
###########################################################################################################
# Z1 is a matrix of observed values of included instruments.

#### Set Instrument ##################################################
# Z2 matrix are observed values of the excluded instruments
if (instrument_case == "SS") { # Use same sex instrument
  idx <- (Z3 == 0)
  Y1 <- Y1[idx]
  Y2 <- Y2[idx]
  Z1matrix <- as.matrix(Z1matrix[idx,])
  # Z = 0 for not twins, not same sex
  # Z = 1 for not twins, same sex
  Z2matrix <- matrix(Z2[idx], ncol=1)
  instrument_descrip <- "SAME SEX"
} else if (instrument_case == "T") { # Use twins instrument
  # Z = 0 for not twins
  # Z = 1 for twins
  Z2matrix <- matrix(Z3, ncol=1)
  instrument_descrip <- "TWINS"
} else { # Use both twins and same sex instruments
  # Z = 0 for not twins, not same sex
  # Z = 1 for not twins, same sex
  # Z = 2 for twins
  instrument_case = "SST"
  Z2matrix <- matrix((1-Z3)*Z2 + 2*Z3, ncol=1)
  instrument_descrip <- "TWINS AND SAME SEX"
}
N = length(Y1)
Zsupport_indices <- matrix(0,nrow=N,ncol=2) # This N*2 matrix indicates which of the ordered support points of Z1 and Z2 correspond to observation i.
Z1support <- as.matrix(unique(Z1matrix))
Z1support <- as.matrix(Z1support[order(Z1support)])
J <- dim(Z1support)[1]
# Index support points of Z1 and Z2
Z2support <- as.matrix(unique(Z2matrix))
Z2support <- as.matrix(Z2support[order(Z2support)])
K <- dim(Z2support)[1]
# Generate unique numerical indices for each point of support for both Z1 and Z2
for(i in 1:N) {
  Zsupport_indices[i,1] <- row.match(Z1matrix[i,],Z1support)
  Zsupport_indices[i,2] <- row.match(Z2matrix[i,],Z2support)
}
#############################################################################

####### Create variable for support of Y and indicators for certain realizations needed for forming conditional moments ####
Ysupport <- rbind(c(0,0),c(0,1),c(1,0),c(1,1))
Yindicators <- cbind((Y1==0) & (Y2==0), (Y1==0) & (Y2==1), !((Y1==1) & (Y2==0)), !((Y1==1) & (Y2==1)), (Y1==0))
Yindicators_zeta <- cbind(1,Yindicators[,c(1,5,4,3,2)]) # rearrange rows into order used in defining components of zeta_hat
# indicators for (0,0),(0,1),!(1,0),!(1,1),(0,.)
############################################################################################################

##### Estimate Sample Moments for Parametric Treatment of Moment Functions ######################
szzeta <- 6*J*K # Number of elements of zeta
zeta_indicators <- matrix(0, nrow=N, ncol = szzeta)
zeta_idx <- 1
for (k in 1:K) { # Support points for excluded exogenous variables Z2
  for (j in 1:J) { # Support point for included exogenous variables Z1
    zeta_indicators[,zeta_idx:(zeta_idx + 5)] = matrix(((Zsupport_indices[,1] == j) & (Zsupport_indices[,2] == k)), nrow=N, ncol=6) * Yindicators_zeta
    zeta_idx <- zeta_idx + 6
  }
}

zeta_hat <- colMeans(zeta_indicators)
zeta_hat_array <- array(data = zeta_hat, dim = c(6,J,K), dimnames = list(c("Pjk","P00jk", "P0jk", "P!11jk", "P!10jk", "P01jk"),1:J,1:K)) # zeta_hat_array[,j,k] is the zeta_hat vector for element j of z1 and element k of z2
svar_normalized_zeta_hat <- var(zeta_indicators)

# Populate the functions that make up the bounds and save their values and derivatives so that
# each only needs to be computed once, and not recomputed for each test.
# bl_vals and bu_vals correspond to lower and upper bounds in (75) - (78)
# bl_derivates and bu_derivates are their respective derivatives wrt inference parameters.
# cl_vals and cu_vals correspond to lower and upper bounds in (71) - (74)
# cl_derivates and cu_derivates are their respective derivatives wrt inference parameters.

bl_vals <- array(0,c(2,J,K,2)) # indices: y2+1, j, k, upperset/lowerset = 2/1
bl_derivatives <- array(0,c(6,2,J,K,2))
bu_vals <- array(0,c(2,J,K,2))
bu_derivatives <- array(0,c(6,2,J,K,2))

cl_vals <- array(0,c(2,J,K,2)) # indices: y2+1, j, k, upperset/lowerset = 2/1
cl_derivatives <- array(0,c(6,2,J,K,2))
cu_vals <- array(0,c(2,J,K,2))
cu_derivatives <- array(0,c(6,2,J,K,2))

for (i in 0:1) { # a value for y2 in the bl and bu functions
  for (j in 1:J) {
    for (k in 1:K) {
      # Set bl_plus values (upper set)
      tmp <- bl(i,j,k,T,zeta_hat_array)
      bl_vals[i+1,j,k,2] <- tmp$value
      bl_derivatives[,i+1,j,k,2] <- tmp$derivative
      # Set cl_plus values (upper set)
      tmp <- cl(i,j,k,T,zeta_hat_array)
      cl_vals[i+1,j,k,2] <- tmp$value
      cl_derivatives[,i+1,j,k,2] <- tmp$derivative
      
      # Set bl_minus values (lower set)
      tmp <- bl(i,j,k,F,zeta_hat_array)
      bl_vals[i+1,j,k,1] <- tmp$value
      bl_derivatives[,i+1,j,k,1] <- tmp$derivative
      # Set cl_minus values (lower set)
      tmp <- cl(i,j,k,F,zeta_hat_array)
      cl_vals[i+1,j,k,1] <- tmp$value
      cl_derivatives[,i+1,j,k,1] <- tmp$derivative
      
      # Set bu_plus values (upper set)
      tmp <- bu(i,j,k,T,zeta_hat_array)
      bu_vals[i+1,j,k,2] <- tmp$value
      bu_derivatives[,i+1,j,k,2] <- tmp$derivative
      # Set cu_plus values (upper set)
      tmp <- cu(i,j,k,T,zeta_hat_array)
      cu_vals[i+1,j,k,2] <- tmp$value
      cu_derivatives[,i+1,j,k,2] <- tmp$derivative
      
      # Set bu_minus values (lower set)
      tmp <- bu(i,j,k,F,zeta_hat_array)
      bu_vals[i+1,j,k,1] <- tmp$value
      bu_derivatives[,i+1,j,k,1] <- tmp$derivative
      # Set cu_minus values (lower set)
      tmp <- cu(i,j,k,F,zeta_hat_array)
      cu_vals[i+1,j,k,1] <- tmp$value
      cu_derivatives[,i+1,j,k,1] <- tmp$derivative
    }
  }
}

# Gather various objects to pass to functions as additional arguments.
arglist <- list(zeta_hat_array = zeta_hat_array, svar_normalized_zeta_hat = svar_normalized_zeta_hat, N=N, J=J, K=K,
                bl_vals = bl_vals, bl_derivatives = bl_derivatives, cl_vals = cl_vals, cl_derivatives = cl_derivatives,
                bu_vals = bu_vals, bu_derivatives = bu_derivatives, cu_vals = cu_vals, cu_derivatives = cu_derivatives) 
###################################################################################################

############ FUNCTION DEFINITIONS FOR INTERSECTION BOUND TESTS ##################################################

######## Function CLR_Test_alpha_upper #############################################################################
# This function computes the moments needed to test whether alpha is in the A upper portion of the identified set
# and then calls CLR_Test to test whether or not the moment inequalities are satisfied.
#################################################################################################################
CLR_Test_alpha_upper <- function(a,alpha=0.05,arglist) {
  result <- compute_alpha_moments(a=a, upperset = T, arglist = arglist)
  return(CLR_Test(moment_estimates = result$moments, V = result$Sigma_hat/N, N = arglist$N, alpha = alpha))
}

######## Function CLR_Test_alpha_lower #############################################################################
# This function computes the moments needed to test whether alpha is in the A lower portion of the identified set
# and then calls CLR_Test to test whether or not the moment inequalities are satisfied.
#################################################################################################################
CLR_Test_alpha_lower <- function(a,alpha=0.05,arglist) {
  result <- compute_alpha_moments(a=a, upperset = F, arglist = arglist)
  return(CLR_Test(moment_estimates = result$moments, V = result$Sigma_hat/N, N = arglist$N, alpha = alpha))
}

######## Function CLR_Test_b0_upper #############################################################################
# This function computes the moments needed to test whether b0 is in the identified set for the upper set
# inequalities and then calls CLR_Test to test whether or not the moment inequalities are satisfied.
#################################################################################################################
CLR_Test_beta0_upper <- function(b0,alpha=0.05,arglist) {
  result <- compute_beta0_moments(b0=b0, upperset = T, arglist = arglist)
  return(CLR_Test(moment_estimates = result$moments, V = result$Sigma_hat/N, N = arglist$N, alpha = alpha))
}

######## Function CLR_Test_b0_lower #############################################################################
# This function computes the moments needed to test whether b0 is in the identified set for the lower set
# inequalities and then calls CLR_Test to test whether or not the moment inequalities are satisfied.
#################################################################################################################
CLR_Test_beta0_lower <- function(b0,alpha=0.05,arglist) {
  result <- compute_beta0_moments(b0=b0, upperset = F, arglist = arglist)
  return(CLR_Test(moment_estimates = result$moments, V = result$Sigma_hat/N, N = arglist$N, alpha = alpha))
}

######## Function CLR_Test_b1_upper #############################################################################
# This function computes the moments needed to test whether b1 is in the identified set for the upper set
# inequalities and then calls CLR_Test to test whether or not the moment inequalities are satisfied.
#################################################################################################################
CLR_Test_beta1_upper <- function(b1,alpha=0.05,arglist) {
  result <- compute_beta1_moments(b1=b1, upperset = T, arglist = arglist)
  return(CLR_Test(moment_estimates = result$moments, V = result$Sigma_hat/N, N = arglist$N, alpha = alpha))
}

######## Function CLR_Test_b1_lower #############################################################################
# This function computes the moments needed to test whether b1 is in the identified set for the lower set
# inequalities and then calls CLR_Test to test whether or not the moment inequalities are satisfied.
#################################################################################################################
CLR_Test_beta1_lower <- function(b1,alpha=0.05,arglist) {
  result <- compute_beta1_moments(b1=b1, upperset = F, arglist = arglist)
  return(CLR_Test(moment_estimates = result$moments, V = result$Sigma_hat/N, N = arglist$N, alpha = alpha))
}

######## Function CLR_Test_Delta_upper #############################################################################
# This function computes the moments needed to test whether Delta(z1) = d is in the A upper portion of the identified set
# and then calls CLR_Test to test whether or not the moment inequalities are satisfied.
#################################################################################################################
CLR_Test_Delta_upper <- function(d,alpha=0.05,arglist) {
  result <- compute_Delta_moments(d = d, z1 = arglist$z1, upperset = T, arglist = arglist)
  return(CLR_Test(moment_estimates = result$moments, V = result$Sigma_hat/N, N = arglist$N, alpha = alpha))
}

######## Function CLR_Test_Delta_lower #############################################################################
# This function computes the moments needed to test whether Delta(z1) = d is in the A lower portion of the identified set
# and then calls CLR_Test to test whether or not the moment inequalities are satisfied.
#################################################################################################################
CLR_Test_Delta_lower <- function(d,alpha=0.05,arglist) {
  result <- compute_Delta_moments(d = d, z1 = arglist$z1, upperset = F, arglist = arglist)
  return(CLR_Test(moment_estimates = result$moments, V = result$Sigma_hat/N, N = arglist$N, alpha = alpha))
}

######## Function CLR_Test_Nonempty_lower #############################################################################
# This function computes the moments needed to test whether A_lower is empty
# and then calls CLR_Test to test whether or not the moment inequalities are satisfied.
#################################################################################################################
CLR_Test_Nonempty_lower <- function(size=0.05,arglist) {
  result <- compute_nonempty_test_moments(upperset = F, arglist = arglist)
  return(CLR_Test(moment_estimates = result$moments, V = result$Sigma_hat/N, N = arglist$N, alpha = size))
}

################### Set parameters for Inference ##################################################
alpha=0.05
stepsize = 0.0001
arglist$LB <- -1
arglist$UB <- 1
###################################################################################################

#empty_lower_set <- CLR_Test_Nonempty_lower(arglist = arglist, size = 0.0001) < 0
empty_lower_set <- CLR_Test_Nonempty_lower(arglist = arglist, size = 0.05)$pcorrected_min < 0

# COMPUTE ANALOG ESTIMATES
alpha_bounds_upper <- compute_alpha_bounds(upperset=T, arglist=arglist)
beta0_bounds_upper <- compute_beta0_bounds(upperset=T, arglist=arglist)
beta1_bounds_upper <- compute_beta1_bounds(upperset=T, arglist=arglist)
Delta0_bounds_upper <- compute_DeltaZ1_bounds(z1 = 0, upperset=T, arglist=arglist)
Delta1_bounds_upper <- compute_DeltaZ1_bounds(z1 = 1, upperset=T, arglist=arglist)

# COMPUTE MEDIAN CORRECTED ESTIMATES
alpha_upper_LB_med_corrected <- find_CI_bound(bound = alpha_bounds_upper[1], isLower = T, alpha = 0.5, stepsize = stepsize,
                                  clrTestFun = CLR_Test_alpha_upper, arglist = arglist, stop_val = 0)
alpha_upper_UB_med_corrected <- find_CI_bound(bound = alpha_bounds_upper[2], isLower = F, alpha = 0.5, stepsize = stepsize,
                                  clrTestFun = CLR_Test_alpha_upper, arglist = arglist, stop_val = 2)
beta0_upper_LB_med_corrected <- find_CI_bound(bound = beta0_bounds_upper[1], isLower = T, alpha = 0.5, stepsize = stepsize,
                                  clrTestFun = CLR_Test_beta0_upper, arglist = arglist, stop_val = -1)
beta0_upper_UB_med_corrected <- find_CI_bound(bound = beta0_bounds_upper[2], isLower = F, alpha = 0.5, stepsize = stepsize,
                                  clrTestFun = CLR_Test_beta0_upper, arglist = arglist, stop_val = 1)
beta1_upper_LB_med_corrected <- find_CI_bound(bound = beta1_bounds_upper[1], isLower = T, alpha = 0.5, stepsize = stepsize,
                                  clrTestFun = CLR_Test_beta1_upper, arglist = arglist, stop_val = -1)
beta1_upper_UB_med_corrected <- find_CI_bound(bound = beta1_bounds_upper[2], isLower = F, alpha = 0.5, stepsize = stepsize,
                                  clrTestFun = CLR_Test_beta1_upper, arglist = arglist, stop_val = 1)

# COMPUTE 95% CONFIDENCE INTERVALS
alpha_upper_LB95 <- find_CI_bound(bound = alpha_bounds_upper[1], isLower = T, alpha = 0.05, stepsize = stepsize,
                                  clrTestFun = CLR_Test_alpha_upper, arglist = arglist, stop_val = 0)
alpha_upper_UB95 <- find_CI_bound(bound = alpha_bounds_upper[2], isLower = F, alpha = 0.05, stepsize = stepsize,
                                  clrTestFun = CLR_Test_alpha_upper, arglist = arglist, stop_val = 2)
beta0_upper_LB95 <- find_CI_bound(bound = beta0_bounds_upper[1], isLower = T, alpha = 0.05, stepsize = stepsize,
                                  clrTestFun = CLR_Test_beta0_upper, arglist = arglist, stop_val = -1)
beta0_upper_UB95 <- find_CI_bound(bound = beta0_bounds_upper[2], isLower = F, alpha = 0.05, stepsize = stepsize,
                                  clrTestFun = CLR_Test_beta0_upper, arglist = arglist, stop_val = 1)
beta1_upper_LB95 <- find_CI_bound(bound = beta1_bounds_upper[1], isLower = T, alpha = 0.05, stepsize = stepsize,
                                  clrTestFun = CLR_Test_beta1_upper, arglist = arglist, stop_val = -1)
beta1_upper_UB95 <- find_CI_bound(bound = beta1_bounds_upper[2], isLower = F, alpha = 0.05, stepsize = stepsize,
                                  clrTestFun = CLR_Test_beta1_upper, arglist = arglist, stop_val = 1)
arglist$z1 = 0 # For Delta0
# COMPUTE MEDIAN CORRECTED ESTIMATES
Delta0_upper_LB_med_corrected <- find_CI_bound(bound = Delta0_bounds_upper[1], isLower = T, alpha = 0.5, stepsize = stepsize,
                                   clrTestFun = CLR_Test_Delta_upper, arglist = arglist, stop_val = -1)
Delta0_upper_UB_med_corrected <- find_CI_bound(bound = Delta0_bounds_upper[2], isLower = F, alpha = 0.5, stepsize = stepsize,
                                   clrTestFun = CLR_Test_Delta_upper, arglist = arglist, stop_val = 1)
# COMPUTE 95% CONFIDENCE INTERVALS
Delta0_upper_LB95 <- find_CI_bound(bound = Delta0_bounds_upper[1], isLower = T, alpha = 0.05, stepsize = stepsize,
                                   clrTestFun = CLR_Test_Delta_upper, arglist = arglist, stop_val = -1)
Delta0_upper_UB95 <- find_CI_bound(bound = Delta0_bounds_upper[2], isLower = F, alpha = 0.05, stepsize = stepsize,
                                   clrTestFun = CLR_Test_Delta_upper, arglist = arglist, stop_val = 1)
arglist$z1 = 1 # For Delta1
# COMPUTE MEDIAN CORRECTED ESTIMATES
Delta1_upper_LB_med_corrected <- find_CI_bound(bound = Delta1_bounds_upper[1], isLower = T, alpha = 0.5, stepsize = stepsize,
                                   clrTestFun = CLR_Test_Delta_upper, arglist = arglist, stop_val = -1)
Delta1_upper_UB_med_corrected <- find_CI_bound(bound = Delta1_bounds_upper[2], isLower = F, alpha = 0.5, stepsize = stepsize,
                                   clrTestFun = CLR_Test_Delta_upper, arglist = arglist, stop_val = 1)
# COMPUTE 95% CONFIDENCE INTERVALS
Delta1_upper_LB95 <- find_CI_bound(bound = Delta1_bounds_upper[1], isLower = T, alpha = 0.05, stepsize = stepsize,
                                   clrTestFun = CLR_Test_Delta_upper, arglist = arglist, stop_val = -1)
Delta1_upper_UB95 <- find_CI_bound(bound = Delta1_bounds_upper[2], isLower = F, alpha = 0.05, stepsize = stepsize,
                                   clrTestFun = CLR_Test_Delta_upper, arglist = arglist, stop_val = 1)

if (!empty_lower_set) {
  # COMPUTE ANALOG ESTIMATES
  alpha_bounds_lower <- compute_alpha_bounds(upperset=F, arglist=arglist)
  beta0_bounds_lower <- compute_beta0_bounds(upperset=F, arglist=arglist)
  beta1_bounds_lower <- compute_beta1_bounds(upperset=F, arglist=arglist)
  Delta0_bounds_lower <- compute_DeltaZ1_bounds(z1 = 0, upperset=F, arglist=arglist)
  Delta1_bounds_lower <- compute_DeltaZ1_bounds(z1 = 1, upperset=F, arglist=arglist)
  
  # COMPUTE MEDIAN CORRECTED ESTIMATES
  alpha_lower_LB_med_corrected <- find_CI_bound(bound = alpha_bounds_lower[1], isLower = T, alpha = 0.50, stepsize = stepsize,
                                    clrTestFun = CLR_Test_alpha_lower, arglist = arglist, stop_val = -2)
  alpha_lower_UB_med_corrected <- find_CI_bound(bound = alpha_bounds_lower[2], isLower = F, alpha = 0.50, stepsize = stepsize,
                                    clrTestFun = CLR_Test_alpha_lower, arglist = arglist, stop_val = 0)
  beta0_lower_LB_med_corrected <- find_CI_bound(bound = beta0_bounds_lower[1], isLower = T, alpha = 0.50, stepsize = stepsize,
                                    clrTestFun = CLR_Test_beta0_lower, arglist = arglist, stop_val = -1)
  beta0_lower_UB_med_corrected <- find_CI_bound(bound = beta0_bounds_lower[2], isLower = F, alpha = 0.50, stepsize = stepsize,
                                    clrTestFun = CLR_Test_beta0_lower, arglist = arglist, stop_val = 1)
  beta1_lower_LB_med_corrected <- find_CI_bound(bound = beta1_bounds_lower[1], isLower = T, alpha = 0.50, stepsize = stepsize,
                                    clrTestFun = CLR_Test_beta1_lower, arglist = arglist, stop_val = -1)
  beta1_lower_UB_med_corrected <- find_CI_bound(bound = beta1_bounds_lower[2], isLower = F, alpha = 0.50, stepsize = stepsize,
                                    clrTestFun = CLR_Test_beta1_lower, arglist = arglist, stop_val = 1)
  
  # COMPUTE 95% CONFIDENCE INTERVALS
  alpha_lower_LB95 <- find_CI_bound(bound = alpha_bounds_lower[1], isLower = T, alpha = 0.05, stepsize = stepsize,
                                    clrTestFun = CLR_Test_alpha_lower, arglist = arglist, stop_val = -2)
  alpha_lower_UB95 <- find_CI_bound(bound = alpha_bounds_lower[2], isLower = F, alpha = 0.05, stepsize = stepsize,
                                    clrTestFun = CLR_Test_alpha_lower, arglist = arglist, stop_val = 0)
  beta0_lower_LB95 <- find_CI_bound(bound = beta0_bounds_lower[1], isLower = T, alpha = 0.05, stepsize = stepsize,
                                    clrTestFun = CLR_Test_beta0_lower, arglist = arglist, stop_val = -1)
  beta0_lower_UB95 <- find_CI_bound(bound = beta0_bounds_lower[2], isLower = F, alpha = 0.05, stepsize = stepsize,
                                    clrTestFun = CLR_Test_beta0_lower, arglist = arglist, stop_val = 1)
  beta1_lower_LB95 <- find_CI_bound(bound = beta1_bounds_lower[1], isLower = T, alpha = 0.05, stepsize = stepsize,
                                    clrTestFun = CLR_Test_beta1_lower, arglist = arglist, stop_val = -1)
  beta1_lower_UB95 <- find_CI_bound(bound = beta1_bounds_lower[2], isLower = F, alpha = 0.05, stepsize = stepsize,
                                    clrTestFun = CLR_Test_beta1_lower, arglist = arglist, stop_val = 1)
  arglist$z1 = 0
  # COMPUTE MEDIAN CORRECTED ESTIMATES
  Delta0_lower_LB_med_corrected <- find_CI_bound(bound = Delta0_bounds_lower[1], isLower = T, alpha = 0.5, stepsize = stepsize,
                                     clrTestFun = CLR_Test_Delta_lower, arglist = arglist, stop_val = -1)
  Delta0_lower_UB_med_corrected <- find_CI_bound(bound = Delta0_bounds_lower[2], isLower = F, alpha = 0.5, stepsize = stepsize,
                                     clrTestFun = CLR_Test_Delta_lower, arglist = arglist, stop_val = 1)
  # COMPUTE 95% CONFIDENCE INTERVALS
  Delta0_lower_LB95 <- find_CI_bound(bound = Delta0_bounds_lower[1], isLower = T, alpha = 0.05, stepsize = stepsize,
                                     clrTestFun = CLR_Test_Delta_lower, arglist = arglist, stop_val = -1)
  Delta0_lower_UB95 <- find_CI_bound(bound = Delta0_bounds_lower[2], isLower = F, alpha = 0.05, stepsize = stepsize,
                                     clrTestFun = CLR_Test_Delta_lower, arglist = arglist, stop_val = 1)
  arglist$z1 = 1
  # COMPUTE MEDIAN CORRECTED ESTIMATES
  Delta1_lower_LB_med_corrected <- find_CI_bound(bound = Delta1_bounds_lower[1], isLower = T, alpha = 0.5, stepsize = stepsize,
                                     clrTestFun = CLR_Test_Delta_lower, arglist = arglist, stop_val = -1)
  Delta1_lower_UB_med_corrected <- find_CI_bound(bound = Delta1_bounds_lower[2], isLower = F, alpha = 0.5, stepsize = stepsize,
                                     clrTestFun = CLR_Test_Delta_lower, arglist = arglist, stop_val = 1)
  
  # COMPUTE 95% CONFIDENCE INTERVALS
  Delta1_lower_LB95 <- find_CI_bound(bound = Delta1_bounds_lower[1], isLower = T, alpha = 0.05, stepsize = stepsize,
                                     clrTestFun = CLR_Test_Delta_lower, arglist = arglist, stop_val = -1)
  Delta1_lower_UB95 <- find_CI_bound(bound = Delta1_bounds_lower[2], isLower = F, alpha = 0.05, stepsize = stepsize,
                                     clrTestFun = CLR_Test_Delta_lower, arglist = arglist, stop_val = 1)
  
}


###### DISPLAY OUTPUT ###############
sink(paste("Section_8_2_2_Inference_", instrument_case, "_Instruments_edu12_dummy.txt", sep=""))
cat(" -- indicator for educ > 12 included, ", instrument_descrip, " INSTRUMENT -- \n", sep="")
cat("================================ \n \n ")
cat("----- A upper set estimates ---- \n ")
cat("Lower bound estimate for alpha = ", alpha_bounds_upper[1], " Upper bound estimate for alpha = ", alpha_bounds_upper[2], "\n", sep = "")
cat("Lower bound estimate for beta0 = ", beta0_bounds_upper[1], " Upper bound estimate for beta0 = ", beta0_bounds_upper[2], "\n", sep = "")
cat("Lower bound estimate for beta1 = ", beta1_bounds_upper[1], " Upper bound estimate for beta1 = ", beta1_bounds_upper[2], "\n", sep = "")
cat("Lower bound estimate for Delta(0) = ", Delta0_bounds_upper[1], " Upper bound estimate for Delta(0) = ", Delta0_bounds_upper[2], "\n", sep = "")
cat("Lower bound estimate for Delta(1) = ", Delta1_bounds_upper[1], " Upper bound estimate for Delta(1) = ", Delta1_bounds_upper[2], "\n", sep = "")

cat("---- A upper 50% confidence intervals, equivalently median corrected estimates --- \n")
cat("Median Corrected lower bound for alpha = ", alpha_upper_LB_med_corrected, " Median Corrected upper bound for alpha = ", alpha_upper_UB_med_corrected, "\n", sep = "")
cat("Median Corrected lower bound for beta0 = ", beta0_upper_LB_med_corrected, " Median Corrected upper bound for beta0 = ", beta0_upper_UB_med_corrected, "\n", sep = "")
cat("Median Corrected lower bound for beta1 = ", beta1_upper_LB_med_corrected, " Median Corrected upper bound for beta1 = ", beta1_upper_UB_med_corrected, "\n", sep = "")
cat("Median Corrected lower bound for Delta(0) = ", Delta0_upper_LB_med_corrected, " Median Corrected upper bound for Delta(0) = ", Delta0_upper_UB_med_corrected, "\n", sep = "")
cat("Median Corrected lower bound for Delta(1) = ", Delta1_upper_LB_med_corrected, " Median Corrected upper bound for Delta(1) = ", Delta1_upper_UB_med_corrected, "\n\n", sep = "")

cat("---- A upper 95% confidence intervals --- \n")
cat("CI lower bound for alpha = ", alpha_upper_LB95, " CI upper bound for alpha = ", alpha_upper_UB95, "\n", sep = "")
cat("CI lower bound for beta0 = ", beta0_upper_LB95, " CI upper bound for beta0 = ", beta0_upper_UB95, "\n", sep = "")
cat("CI lower bound for beta1 = ", beta1_upper_LB95, " CI upper bound for beta1 = ", beta1_upper_UB95, "\n", sep = "")
cat("CI lower bound for Delta(0) = ", Delta0_upper_LB95, " CI upper bound for Delta(0) = ", Delta0_upper_UB95, "\n", sep = "")
cat("CI lower bound for Delta(1) = ", Delta1_upper_LB95, " CI upper bound for Delta(1) = ", Delta1_upper_UB95, "\n\n", sep = "")

if (!empty_lower_set) {
  cat("----- A lower set estimates ---- \n ")
  cat("Lower bound estimate for alpha = ", alpha_bounds_lower[1], " Upper bound estimate for alpha = ", alpha_bounds_lower[2], "\n", sep = "")
  cat("Lower bound estimate for beta0 = ", beta0_bounds_lower[1], " Upper bound estimate for beta0 = ", beta0_bounds_lower[2], "\n", sep = "")
  cat("Lower bound estimate for beta1 = ", beta1_bounds_lower[1], " Upper bound estimate for beta1 = ", beta1_bounds_lower[2], "\n", sep = "")
  cat("Lower bound estimate for Delta(0) = ", Delta0_bounds_lower[1], " Upper bound estimate for Delta(0) = ", Delta0_bounds_lower[2], "\n", sep = "")
  cat("Lower bound estimate for Delta(1) = ", Delta1_bounds_lower[1], " Upper bound estimate for Delta(1) = ", Delta1_bounds_lower[2], "\n", sep = "")

  cat("---- A upper 50% confidence intervals, equivalently median corrected estimates --- \n")
  cat("Median corrected lower bound for alpha = ", alpha_lower_LB_med_corrected, " Median corrected upper bound for alpha = ", alpha_lower_UB_med_corrected, "\n", sep = "")
  cat("Median corrected lower bound for beta0 = ", beta0_lower_LB_med_corrected, " Median corrected upper bound for beta0 = ", beta0_lower_UB_med_corrected, "\n", sep = "")
  cat("Median corrected lower bound for beta1 = ", beta1_lower_LB_med_corrected, " Median corrected upper bound for beta1 = ", beta1_lower_UB_med_corrected, "\n", sep = "")
  cat("Median corrected lower bound for Delta(0) = ", Delta0_lower_LB_med_corrected, " Median corrected upper bound for Delta(0) = ", Delta0_lower_UB_med_corrected, "\n", sep = "")
  cat("Median corrected lower bound for Delta(1) = ", Delta1_lower_LB_med_corrected, " Median corrected upper bound for Delta(1) = ", Delta1_lower_UB_med_corrected, "\n\n", sep = "")

    cat("---- A upper 95% confidence intervals --- \n")
  cat("CI lower bound for alpha = ", alpha_lower_LB95, " CI upper bound for alpha = ", alpha_lower_UB95, "\n", sep = "")
  cat("CI lower bound for beta0 = ", beta0_lower_LB95, " CI upper bound for beta0 = ", beta0_lower_UB95, "\n", sep = "")
  cat("CI lower bound for beta1 = ", beta1_lower_LB95, " CI upper bound for beta1 = ", beta1_lower_UB95, "\n", sep = "")
  cat("CI lower bound for Delta(0) = ", Delta0_lower_LB95, " CI upper bound for Delta(0) = ", Delta0_lower_UB95, "\n", sep = "")
  cat("CI lower bound for Delta(1) = ", Delta1_lower_LB95, " CI upper bound for Delta(1) = ", Delta1_lower_UB95, "\n\n", sep = "")
} else {
  cat("Lower set inequalities are rejected at the 0.05 level. \n")
}
sink()