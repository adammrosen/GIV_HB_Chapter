####### Function AIS_DiscreteCLR_Upper #####
# -- Input Parameters --
# bound_estimates: A vector of moment estimates that are each an upper bound on the same quantity, e.g. all restricted >= 0
# correlation_matrix: A consistent estimator of the correlation matrix of the bound_estimates
# s_n: A vector of the standard errors of bound_estimates.
# N: Sample size
# sim_draws: Simulation draws from which the asymptotic distribution is approximate
# -- Returns --
#   The indices of the bound_estimates that are found to be in the contact_set
#   estimated by adaptive inequality selection as in Chernozhukov, Lee, and Rosen (2013)
###################################################################################
AIS_DiscreteCLR_Upper <- function(bound_estimates,correlation_matrix,s_n,N,sim_draws) {
  
  p_bar <- 1-0.1/(log(N))
  
  tmp_mat <- sim_draws[cbind(seq(1,dim(sim_draws)[1]),max.col(sim_draws))]
  
  # Compute a high-level quantile of the max of the appropriate multivariate normal statistic
  k_bar <- quantile(tmp_mat,p_bar)
  
  # Compute the minimum of the precision-corrected estimates.
  Ustar <- min(bound_estimates + k_bar*s_n)
  
  # Return the indices of bound_estimates that are close to the minimum
  return( which( bound_estimates <= (Ustar + 2*s_n*k_bar) ) )
}

###### Function CLR_Test #########################################################################
# Test whether or not the given moments are nonnegative
# -- Input parameters ---
# moment_estimates: A J-vector of empirical moments to test
# V: The variance matrix of the moment estimates
# N: Sample size for data used to compute moment_estimates
# R: Number of simulation draws to use
# alpha: Size of test.
# --- Output parameters ---
#   $pcorrected_min: minimum of the moment estimates after they have been corrected.
#       by the computed critical value times their standard error.
#   $contact_set: the components of the moment_estimates in the estimated contact set.
##################################################################################################
CLR_Test <- function(moment_estimates, V, N, R = 10000, alpha = 0.05) {
  
  # -- Preliminaries --
  nil <- 0.00000000000001 # trimming value for standard errors to deal with cases equal to zero
  J <- length(moment_estimates)
  s_n <- sqrt(diag(V))
  stderrors <- (s_n >= nil) * s_n + (s_n < nil) 
  D <- diag(1/stderrors)
  Omega_hat <- D%*%V%*%D
  simdraws <- rmvnorm(R,rep(0,J),Omega_hat,method="svd")
  
  # Compute the set of bound estimates that are close to the minimum using Adaptive Inequality Selection.
  contact_set <- AIS_DiscreteCLR_Upper(bound_estimates = moment_estimates,
                                       correlation_matrix = Omega_hat,
                                       s_n = s_n, N = N, sim_draws = simdraws)
  
  # Extract columns from the simulation draw  corresponding to the contact set.
  simdraws <- simdraws[,contact_set]
  
  # Compute 1-alpha level critical value.
  kp <- ifelse (length(contact_set)==1,qnorm(1-alpha,0,1),quantile(simdraws[cbind(seq(1,R),max.col(simdraws))],1-alpha))
  pcorrected_min <- min(moment_estimates + s_n * kp)
  return(list(pcorrected_min = pcorrected_min, contact_set = contact_set ))
}

####### Function find_CI_bound ###################################################################
# This function searches for the lower or upper bound of a confidence interval for a partially
# identified parameter, where the confidence interval is constructed by inverting an intersection
# bounds test.
# INPUT PARAMETERS
#   bound: This should be either the lower endpoint or upper endpoint of the identification region
#          for a parameter of interest. The function then searches incrementally
#          below (above) the lower (upper) endpoint of the interval for points that the intersection
#          bound test does not reject. It returns stepsize minus the least such point if isLower = T
#          and stepsize plus the greatest such point if isLower = F.
#   isLower: A boolean indicator for whether the bound input is a lower bound estimate. If True,
#          the procedure searches incrementally for parameter values below the bound. If False,
#          the procedure searches incrementally for values above the bound.
#   alpha: The size of the intersection bound test.
#   stepsize: Step-size for the incremental search.
#   clrTestFun: A function that tests whether or not a given parameter value satisfies a collection of
#          of moment inequalities as intersection bounds. The null hypothesis of the test must be
#          that all moments are greater than or equal to zero.
#         
#          clrTestFun must take three arguments. The first argument is the value x of a parameter being
#          tested, the second argument is the level of the test, and the third argument is a list of any
#          additional options or arguments for the inequality test the clrTestFun performs.
#         
#          clrTestFun must return the precision corrected minimum of the moment inequalities that are
#          being tested. The level of the precision correction is at least 1-alpha, such that the test
#          rejects that the parameter value x satisfies the moment conditions at level alpha if
#          the precision corrected minimum is below zero.
#   arglist: A list of additional arguments that is passed to clrTestFun.
#   stop_val: The value of x at which to terminate the search.
#   digits: The number of places to round the final answer.
# OUTPUT PARAMETERS
#   The value of x returned is stepsize minus the smallest point not rejected by a level 
#   alpha intersection bound test if isLower = T and stepsize plus the greatest such point if isLower = F.
#   The return value is the lower point of a confidence interval for the parameter of interest is
#   isLower = T, and it is the upper point of a confidence interval for the parameter of interest
#   if isLower = F.
####################################################################################################
find_CI_bound <- function(bound,isLower,alpha,stepsize,clrTestFun,arglist,stop_val,digits=4) {
    x <- bound
    last_value_in <- bound
    sgn <- 2*isLower-1 # 1 if lower bound, -1 if upper bound
    # Search for furthest point between bound and stop_val that is not rejected at level alpha
    while (sgn*(stop_val - x) <= 0) {
      clrtest_output <- clrTestFun(x,alpha=alpha,arglist=arglist)
      if (clrtest_output$pcorrected_min >= 0) {last_value_in <- x} # x is not rejected by the test
      x <- (x - sgn * stepsize)
    }
    # Reduce stepsize by a factor of 10 and examine points on the boundary betweenrejection and non-rejection.
    refine_stop_val = last_value_in - sgn*stepsize
    refine_ss <- stepsize/10
    x <- last_value_in
    while (sgn*(refine_stop_val - x) <= 0) {
      clrtest_output <- clrTestFun(x,alpha=alpha,arglist=arglist)
      if (clrtest_output$pcorrected_min >= 0) {last_value_in <- x} # x is not rejected by the test
      x <- (x - sgn * refine_ss)
    }
    return(round(last_value_in - sgn*refine_ss,digits))
}
