####### Inference_Functions_Probit_Projections_3 ########################################
# This file contains functions used for the parametric IV probit specification used in 
# Section 8.2.2 of the Handbook of Econometrics chapter entitied "Generalized Instrumental
# Variable Models, Methods, and Applications" by Chesher and Rosen (2019).
#########################################################################################

###### Function dPhiInv ##################################################################################
# This function compute the derivative of the standard normal quantile function (x)
# -- Input parameters ---
#   x: The value at which to evaluate the derivate of the normal quantile function.
# --- Output parameters ---
#   The value of the function at x
##########################################################################################################
dPhiInv <- function(x) {
  return(1/(dnorm(qnorm(x))))
}

###### Function bl ##################################################################################
# This is a bounding function for a case with included exogenous variables.
# Specifically, this computes the lower bounds appearing in inequalities (75) - (78)
# as functions of the inference parameters decribed in the text.
# These bounds all given by the normal quantile function applied to functions of inference parameters.
# -- Input parameters ---
#   y2: The value of y2 at which to evaluate the bounding function.
#    j: The index of the support point for Z1 at which to evaluate the bounding function.
#    k: The index of the support point for Z2 at which to evaluate the bounding function.
#   upperset: A boolean. T to indicate the bl+ bounding function for A_upper, otherwise bl- for A_lower
#   b: The 6*J*K array of estimated inference parameters from which the bounding functions are computed
# --- Output parameters ---
#   A list of:  $value: The value of the function
#               $derivative: the derivative of the function wrt zeta_hat[1:6,j,k]
##########################################################################################################
bl <- function(y2, j, k, upperset, b) {
  derivative <- rep(0,6) # Initialize derivative array
  # Set numerator of the index in the expression for the bounding function
  i <- upperset * ((1-y2) * 2 + y2 * 3) + (1-upperset) * ((1-y2) * 3 + y2 * 6)
  value <- qnorm(b[i,j,k]/b[1,j,k])
  derivative[1] <- -b[i,j,k]/(b[1,j,k]^2) * dPhiInv(b[i,j,k]/b[1,j,k])
  derivative[i] <- (1/b[1,j,k]) * dPhiInv(b[i,j,k]/b[1,j,k])
  return( list( value = value, derivative = derivative))
}

###### Function cl ##################################################################################
# This is a bounding function for a case with included exogenous variables
# Specifically, this computes the lower bounds appearing in inequalities (71) - (74)
# as functions of the inference parameters decribed in the text.
# These bounds all functions of inference parameters. They are the same as those used
# to define bl, but without application of the the normal quantile function.
# -- Input parameters ---
#   y2: The value of y2 at which to evaluate the bounding function.
#    j: The index of the support point for Z1 at which to evaluate the bounding function.
#    k: The index of the support point for Z2 at which to evaluate the bounding function.
#   upperset: A boolean. T to indicate the cl+ bounding function for A_upper, otherwise cl- for A_lower
#   b: The 6*J*K array of estimated zeta parameters of which the bounding functions are estimates.
# --- Output parameters ---
#   A list of:  $value: The value of the function
#               $derivative: the derivative of the function wrt zeta_zat[1:6,j,k]
##########################################################################################################
cl <- function(y2, j, k, upperset, b) {
  derivative <- rep(0,6) # Initialize derivative array
  # Set numerator of the index in the expression for the bounding function
  i <- upperset * ((1-y2) * 2 + y2 * 3) + (1-upperset) * ((1-y2) * 3 + y2 * 6)
  value <- b[i,j,k]/b[1,j,k]
  derivative[1] <- -b[i,j,k]/(b[1,j,k]^2)
  derivative[i] <- 1/b[1,j,k]
  return( list( value = value, derivative = derivative))
}

##### Function bu ##################################################################################
# This is a bounding function for a case with included exogenous variables.
# Specifically, this computes the upper bounds appearing in inequalities (77) - (80)
# as functions of the inference parameters decribed in the text.
# These bounds all given by the normal quantile function applied to functions of inference parameters.
# -- Input parameters ---
#   y2: The value of y2 at which to evaluate the bounding function.
#    j: The index of the support point for Z1 at which to evaluate the bounding function.
#    k: The index of the support point for Z2 at which to evaluate the bounding function.
#   upperset: A boolean. T to indicate the bu+ bounding function for A_upper, otherwise bu- for A_lower
#   b: The 6*J*K array of estimated inference parameters from which the bounding functions are computed
# --- Output parameters ---
#   A list of:  $value: The value of the function
#               $derivative: the derivative of the function wrt zeta_hat[1:6,j,k]
##########################################################################################################
bu <- function(y2, j, k, upperset, b) {
  derivative <- rep(0,6) # Initialize derivative array
  # Set numerator of the index in the expression for the bounding function
  i <- upperset * ((1-y2) * 3 + y2 * 4)  + (1-upperset) * ((1-y2) * 5 + y2 * 3)
  value <- qnorm(b[i,j,k]/b[1,j,k])
  derivative[1] <- -b[i,j,k]/(b[1,j,k]^2) * dPhiInv(b[i,j,k]/b[1,j,k])
  derivative[i] <- (1/b[1,j,k]) * dPhiInv(b[i,j,k]/b[1,j,k])
  return( list( value = value, derivative = derivative))
}

###### Function cu ##################################################################################
# This is a bounding function for a case with included exogenous variables
# Specifically, this computes the upper bounds appearing in inequalities (73) - (76)
# as functions of the inference parameters decribed in the text.
# These bounds all functions of inference parameters. They are the same as those used
# to define bl, but without application of the the normal quantile function.
# -- Input parameters ---
#   y2: The value of y2 at which to evaluate the bounding function.
#    j: The index of the support point for Z1 at which to evaluate the bounding function.
#    k: The index of the support point for Z2 at which to evaluate the bounding function.
#   upperset: A boolean. T to indicate the cu+ bounding function for A_upper, otherwise cu- for A_lower
#   b: The 6*J*K array of estimated zeta parameters of which the bounding functions are estimates.
# --- Output parameters ---
#   A list of:  $value: The value of the function
#               $derivative: the derivative of the function wrt zeta_hat[1:6,j,k]
##########################################################################################################
cu <- function(y2, j, k, upperset, b) {
  derivative <- rep(0,6) # Initialize derivative array
  # Set numerator of the index in the expression for the bounding function
  i <- upperset * ((1-y2) * 3 + y2 * 4)  + (1-upperset) * ((1-y2) * 5 + y2 * 3)
  value <- b[i,j,k]/b[1,j,k]
  derivative[1] <- -b[i,j,k]/(b[1,j,k]^2)
  derivative[i] <- 1/b[1,j,k]
  return( list( value = value, derivative = derivative))
}

################ Function compute_alpha_moments ###############################################
# This function computes the moment inequalities for values of parameter alpha.
# Here alpha is the coefficient on the endogenous variable in an IV
# probit model with an included binary variable and an instrument taking 3 values.
# An estimator for the asymptotic variance of sqrt(n) times the sample moments in also computed. 
# INPUT PARAMETERS
#   a: A fixed value of alpha for which the hypothesis alpha = a is to be tested.
#   upperset: Boolean indicating whether to test the moment in A_upper
#   arglist: A list of additional arguments passed, which must include
#         $bl_vals: An array of dimension 2*J*K*2. The second and third dimension correspond
#                   to support points of Z1 and Z2.  The first dimension is 1 for y2==0 and
#                   is 2 if for y2==1.  The fourth dimension is 1 if the value is for the
#                   bl_minus function and 2 if for the bl_plus function.
#         $bu_vals: An 2*J*K*2 array similar to the above but for the bu function.
#         $bl_derivatives: a 6*2*J*K*2 array indicating derivatives for the bl function
#                   with respect to the population means of which they are functions.
#         $bu_derivatives: An analgous 6*2*J*K*2 array of derivatives for the bu function.
#         $svar_normalized_zeta_hat: a consistent estimator of the asymptotic variance of sqrt(n)*zeta_hat.
# OUTPUT PARAMETERS (as a list)
#   moments: The value of the sample moments evaluated the input delta_value and zeta_hat
#   Sigma_hat: An estimator for the asymptotic variance of sqrt(n) times the sample moments computed 
#              by application of the delta method.
#####################################################################################################
compute_alpha_moments <- function(a, upperset, arglist) {
  bl_vals <- arglist$bl_vals[,,,upperset+1]
  bu_vals <- arglist$bu_vals[,,,upperset+1]
  bl_derivatives <- arglist$bl_derivatives[,,,,upperset+1]
  bu_derivatives <- arglist$bu_derivatives[,,,,upperset+1]
  J <- dim(bu_vals)[2]
  K <- dim(bu_vals)[3]
  moments <- rep(0,J * K * ((4 * K) - 2))
  # array of moment derivatives
  dmdz <- array(0,c(length(moments), dim(arglist$zeta_hat_array)))
  i = 0 # row counter
  for (k1 in 1:K) {
    for (j in 1:J) {
      for (k2 in 1:K) { # Note the first arguments to bl_vals, bu_vals, and derivatives are offset by one due to array being indexed by one rather than zero
        i <- i + 1
        moments[i] <- a - bl_vals[2,j,k1] + bu_vals[1,j,k2]
        dmdz[i,,j,k1] <-  -bl_derivatives[,2,j,k1]
        dmdz[i,,j,k2] <-  dmdz[i,,j,k2] + bu_derivatives[,1,j,k2] # if k1 == k2, then including the first term is necessary
        i <- i + 1
        moments[i] <- bu_vals[2,j,k1] - bl_vals[1,j,k2] - a
        dmdz[i,,j,k1] <- bu_derivatives[,2,j,k1]
        dmdz[i,,j,k2] <- dmdz[i,,j,k2] - bl_derivatives[,1,j,k2] # if k1 == k2, then including the first term is necessary
        if (k1 != k2) { # These inequalities are automatically satisfied if k1 == k2, so skip them.
          i <- i + 1
          moments[i] <- bu_vals[1,j,k1] - bl_vals[1,j,k2]
          dmdz[i,,j,k1] <- bu_derivatives[,1,j,k1]
          dmdz[i,,j,k2] <- -bl_derivatives[,1,j,k2]
          i <- i + 1
          moments[i] <- bu_vals[2,j,k1] - bl_vals[2,j,k2]
          dmdz[i,,j,k1] <- bu_derivatives[,2,j,k1]
          dmdz[i,,j,k2] <- -bl_derivatives[,2,j,k2]
        }
      }
    }
  }
  dmdz_matrix <- matrix(dmdz, nrow = length(moments), ncol = 6*J*K)
  
  # Now remove moments that are Inf, if any.
  # This happens for example with f(0,0|z1,z2=twins) which causes
  # bl_vals[1,2,2,2] = bl_vals[1,1,2,2] = -Inf
  # This is because when there is a twin second birth, the probability of < 3 children is zero
  # Such moments can be discarded.
  
  finite.moments <- which(moments < Inf) # indices of finite moments
  moments <- moments[finite.moments]
  dmdz_matrix <- dmdz_matrix[finite.moments,]
  
  Sigma_hat <- dmdz_matrix %*% arglist$svar_normalized_zeta_hat %*% t(dmdz_matrix)
  return( list(moments=moments, Sigma_hat=Sigma_hat) )
}

################ Function compute_beta1_moments ###############################################
# This function computes the moment inequalities for values of parameter beta1, the slope
# coefficient on the included exogenous variable in the IV probit specfication.
# An estimator for the asymptotic variance of sqrt(n) times the sample moments in also computed. 
# INPUT PARAMETERS
#   b1: A fixed value for b1, for which the hypothesis is to be tested.
#   upperset: Boolean indicating whether to test the moment in A_upper
#   arglist: A list of additional arguments passed, which must include
#         $bl_vals: An array of dimension 2*J*K*2. The second and third dimension correspond
#                   to support points of Z1 and Z2.  The first dimension is 1 if for y2==0 and
#                   is 2 if for y2==1.  The fourth dimension is 1 if the value is for the
#                   bl_minus function and 2 if for the bl_plus function.
#         $bu_vals: An 2*J*K*2 array similar to the above but for the bu function.
#         $bl_derivatives: a 6*2*J*K*2 array indicating derivatives for the bl function
#                   with respect to the population means of which they are functions.
#         $bu_derivatives: An analgous 6*2*J*K*2 array of derivatives for the bu function.
#         $svar_normalized_zeta_hat: a consistent estimator of the asymptotic variance of sqrt(n)*zeta_hat.
# OUTPUT PARAMETERS (as a list)
#   moments: The value of the sampel moments evaluated the input delta_value and zeta_hat
#   Sigma_hat: An estimator for the asymptotic variance of sqrt(n) times the sample moments computed 
#              by application of the delta method.
# NOTE: IMPLEMENTATION ONLY VALID FOR J=2.
#####################################################################################################
compute_beta1_moments <- function(b1, upperset, arglist) {
  bl_vals <- arglist$bl_vals[,,,upperset+1]
  bu_vals <- arglist$bu_vals[,,,upperset+1]
  bl_derivatives <- arglist$bl_derivatives[,,,,upperset+1]
  bu_derivatives <- arglist$bu_derivatives[,,,,upperset+1]
  J <- dim(bu_vals)[2]
  K <- dim(bu_vals)[3]
  moments <- rep(0,4*K^2 + 2*K*(K-1)*J)
  # array of moment derivatives
  dmdz <- array(0,c(length(moments), dim(arglist$zeta_hat_array)))
  i = 0 # row counter
  for (k1 in 1:K) {
      for (k2 in 1:K) { # Note the first arguments to bl_vals, bu_vals, and derivatives are offset by one due to array being indexed by one rather than zero
        i <- i + 1
        moments[i] <- b1 - bl_vals[1,2,k1] + bu_vals[1,1,k2]
        dmdz[i,,2,k1] <- -bl_derivatives[,1,2,k1]
        dmdz[i,,1,k2] <- bu_derivatives[,1,1,k2]
        i <- i + 1
        moments[i] <- b1 - bl_vals[2,2,k1] + bu_vals[2,1,k2]
        dmdz[i,,2,k1] <- -bl_derivatives[,2,2,k1]
        dmdz[i,,1,k2] <- bu_derivatives[,2,1,k2]
        i <- i + 1
        moments[i] <- bu_vals[1,2,k1] - bl_vals[1,1,k2] - b1
        dmdz[i,,j,k1] <- bu_derivatives[,1,2,k1]
        dmdz[i,,j,k2] <- -bl_derivatives[,1,1,k2]
        i <- i + 1
        moments[i] <- bu_vals[2,2,k1] - bl_vals[2,1,k2] - b1
        dmdz[i,,j,k1] <- bu_derivatives[,2,2,k1]
        dmdz[i,,j,k2] <- -bl_derivatives[,2,1,k2]
        if (k1 != k2) { # Now include moments that do not involve b1, but that must be satisfied.
          for (j in 1:J) {
            i <- i + 1
            moments[i] <- bu_vals[1,j,k1] - bl_vals[1,j,k2]
            dmdz[i,,j,k1] <- bu_derivatives[,1,j,k1]
            dmdz[i,,j,k2] <- -bl_derivatives[,1,j,k2]
            i <- i + 1
            moments[i] <- bu_vals[2,j,k1] - bl_vals[2,j,k2]
            dmdz[i,,j,k1] <- bu_derivatives[,2,j,k1]
            dmdz[i,,j,k2] <- -bl_derivatives[,2,j,k2]
          }
        }
      }
    }
  dmdz_matrix <- matrix(dmdz, nrow = length(moments), ncol = 6*J*K)
  
  # Discard infinite moments.
  finite.moments <- which(moments < Inf) # indices of finite moments
  moments <- moments[finite.moments]
  dmdz_matrix <- dmdz_matrix[finite.moments,]
  
  Sigma_hat <- dmdz_matrix %*% arglist$svar_normalized_zeta_hat %*% t(dmdz_matrix)
  return( list(moments=moments, Sigma_hat=Sigma_hat) )
}

################ Function compute_beta0_moments ###############################################
# This function computes the moment inequalities for values of parameter beta0, the
# intercept in the IV probit specfication.
# An estimator for the asymptotic variance of sqrt(n) times the sample moments in also computed. 
# INPUT PARAMETERS
#   b0: A fixed value for b0, for which the hypothesis is to be tested.
#   upperset: Boolean indicating whether to test the moment in A_upper
#   arglist: A list of additional arguments passed, which must include
#         $bl_vals: An array of dimension 2*J*K*2. The second and third dimension correspond
#                   to support points of Z1 and Z2.  The first dimension is 1 if for y2==0 and
#                   is 2 if for y2==1.  The fourth dimension is 1 if the value is for the
#                   bl_minus function and 2 if for the bl_plus function.
#         $bu_vals: An 2*J*K*2 array similar to the above but for the bu function.
#         $bl_derivatives: a 6*2*J*K*2 array indicating derivatives for the bl function
#                   with respect to the population means of which they are functions.
#         $bu_derivatives: An analgous 6*2*J*K*2 array of derivatives for the bu function.
#         $svar_normalized_zeta_hat: a consistent estimator of the asymptotic variance of sqrt(n)*zeta_hat.
# OUTPUT PARAMETERS (as a list)
#   moments: The value of the sampel moments evaluated the input delta_value and zeta_hat
#   Sigma_hat: An estimator for the asymptotic variance of sqrt(n) times the sample moments computed 
#              by application of the delta method.
# NOTE: IMPLEMENTATION ONLY VALID FOR J=2.
#####################################################################################################
compute_beta0_moments <- function(b0, upperset, arglist) {
  bl_vals <- arglist$bl_vals[,,,upperset+1]
  bu_vals <- arglist$bu_vals[,,,upperset+1]
  bl_derivatives <- arglist$bl_derivatives[,,,,upperset+1]
  bu_derivatives <- arglist$bu_derivatives[,,,,upperset+1]
  J <- dim(bu_vals)[2]
  K <- dim(bu_vals)[3]
  moments <- rep(0,4*K*(K-1) + 2*K + 2*K^3)
  # array of moment derivatives
  dmdz <- array(0,c(length(moments), dim(arglist$zeta_hat_array)))
  i = 0 # row counter
  for (k1 in 1:K) {
      i <- i + 1
      moments[i] <- b0 - bl_vals[1,1,k1]
      dmdz[i,,1,k1] <- -bl_derivatives[,1,1,k1]
      i <- i+1
      moments[i] <- bu_vals[1,1,k1] - b0
      dmdz[i,,1,k1] <- bu_derivatives[,1,1,k1]
    for (k2 in 1:K) {
      if (k1 != k2) { # Include moments that do not involve b1, but that must be satisfied.
        for (j in 1:J) {
          i <- i + 1
          moments[i] <- bu_vals[1,j,k1] - bl_vals[1,j,k2]
          dmdz[i,,j,k1] <- bu_derivatives[,1,j,k1]
          dmdz[i,,j,k2] <- -bl_derivatives[,1,j,k2]
          i <- i + 1
          moments[i] <- bu_vals[2,j,k1] - bl_vals[2,j,k2]
          dmdz[i,,j,k1] <- bu_derivatives[,2,j,k1]
          dmdz[i,,j,k2] <- -bl_derivatives[,2,j,k2]
        }
      }
      for (k3 in 1:K) {
        i <- i + 1
        moments[i] <- b0 - bl_vals[1,2,k1] - bl_vals[2,1,k2] + bu_vals[2,2,k3]
        dmdz[i,,2,k1] <- -bl_derivatives[,1,2,k1]
        dmdz[i,,1,k2] <- dmdz[i,,1,k2] - bl_derivatives[,2,1,k2] # first term in case k1 = k2
        dmdz[i,,2,k3] <- dmdz[i,,1,k3] + bu_derivatives[,2,2,k3] # first term in case k3 = k1 or k2
        i <- i + 1
        moments[i] <- bu_vals[1,2,k1] + bu_vals[2,1,k2] - bl_vals[2,2,k3] - b0
        dmdz[i,,2,k1] <- bu_derivatives[,1,2,k1]
        dmdz[i,,1,k2] <- dmdz[i,,1,k2] + bu_derivatives[,2,1,k2] # first term in case k1 = k2
        dmdz[i,,2,k3] <- dmdz[i,,1,k3] - bl_derivatives[,2,2,k3] # first term in case k3 = k1 or k2
      }
    }
  }
  dmdz_matrix <- matrix(dmdz, nrow = length(moments), ncol = 6*J*K)
  
  # Discard infinite moments.
  finite.moments <- which(moments < Inf) # indices of finite moments
  moments <- moments[finite.moments]
  dmdz_matrix <- dmdz_matrix[finite.moments,]
  
  Sigma_hat <- dmdz_matrix %*% arglist$svar_normalized_zeta_hat %*% t(dmdz_matrix)
  return( list(moments=moments, Sigma_hat=Sigma_hat) )
}

################ Function compute_Delta_moments ###############################################
# This function computes the moment inequalities for values of parameter Delta(0) or Delta(1),
# the ATE at Z1 = 0 and Z1 = 1.
# An estimator for the asymptotic variance of sqrt(n) times the sample moments in also computed. 
# INPUT PARAMETERS
#   d: A fixed value for Delta(z1), for which the hypothesis is to be tested.
#   z1: The fixed value of z1, either one or zero, at which to consider Delta(z1)
#   upperset: Boolean indicating whether to test the moment in A_upper
#   arglist: A list of additional arguments passed, which must include
#         $bl_vals: An array of dimension 2*J*K*2. The second and third dimension correspond
#                   to support points of Z1 and Z2.  The first dimension is 1 if for y2==0 and
#                   is 2 if for y2==1.  The fourth dimension is 1 if the value is for the
#                   bl_minus function and 2 if for the bl_plus function.
#         $bu_vals: An 2*J*K*2 array similar to the above but for the bu function.
#         $bl_derivatives: a 6*2*J*K*2 array indicating derivatives for the bl function
#                   with respect to the population means of which they are functions.
#         $bu_derivatives: An analgous 6*2*J*K*2 array of derivatives for the bu function.
#         $svar_normalized_zeta_hat: a consistent estimator of the asymptotic variance of sqrt(n)*zeta_hat.
# OUTPUT PARAMETERS (as a list)
#   moments: The value of the sampel moments evaluated the input delta_value and zeta_hat
#   Sigma_hat: An estimator for the asymptotic variance of sqrt(n) times the sample moments computed 
#              by application of the delta method.
# NOTE: IMPLEMENTATION ONLY VALID FOR J=2.
#####################################################################################################
compute_Delta_moments <- function(d, z1, upperset, arglist) {
  cl_vals <- arglist$cl_vals[,,,upperset+1]
  cu_vals <- arglist$cu_vals[,,,upperset+1]
  cl_derivatives <- arglist$cl_derivatives[,,,,upperset+1]
  cu_derivatives <- arglist$cu_derivatives[,,,,upperset+1]
  J <- dim(cu_vals)[2]
  K <- dim(cu_vals)[3]
  zj <- z1 + 1 # The index of the value of z1 for the cl and cu functions, as arrays are indexed from 1.
  moments <- rep(0,K*(2*K+(K-1)*(2*J)))
  # array of moment derivatives
  dmdz <- array(0,c(length(moments), dim(arglist$zeta_hat_array)))
  i = 0 # row counter
  for (k1 in 1:K) {
    for (k2 in 1:K) {
      i <- i + 1
      moments[i] <- cu_vals[1,zj,k1] - cl_vals[2,zj,k2] - d
      dmdz[i,,zj,k1] <- cu_derivatives[,1,zj,k1]
      dmdz[i,,zj,k2] <- dmdz[i,,zj,k2] - cl_derivatives[,2,zj,k2] # The first term is needed when k1 = k2.
      i <- i + 1
      moments[i] <- d - cl_vals[1,zj,k1] + cu_vals[2,zj,k2]
      dmdz[i,,zj,k1] <- -cl_derivatives[,1,zj,k1]
      dmdz[i,,zj,k2] <- dmdz[i,,zj,k2] + cu_derivatives[,2,zj,k2] # The first term is needed when k1 = k2.
      if (k1 != k2) { # Include moments that do not involve b1, but that must be satisfied.
        for (j in 1:J) {
          i <- i + 1
          moments[i] <- cu_vals[1,j,k1] - cl_vals[1,j,k2]
          dmdz[i,,j,k1] <- cu_derivatives[,1,j,k1]
          dmdz[i,,j,k2] <- -cl_derivatives[,1,j,k2]
          i <- i + 1
          moments[i] <- cu_vals[2,j,k1] - cl_vals[2,j,k2]
          dmdz[i,,j,k1] <- cu_derivatives[,2,j,k1]
          dmdz[i,,j,k2] <- -cl_derivatives[,2,j,k2]
        }
      }
    }
  }
  dmdz_matrix <- matrix(dmdz, nrow = length(moments), ncol = 6*J*K)
  Sigma_hat <- dmdz_matrix %*% arglist$svar_normalized_zeta_hat %*% t(dmdz_matrix)
  return( list(moments=moments, Sigma_hat=Sigma_hat) )
}

################ Function compute_nonempty_test_moments ###############################################
# This function computes a collection of moments needed for either A_upper or A_lower (as specified)
# to be non-empty, but do that not explicitly involve model parameters, in the IV binary outcome
# model with an included exogenous variable Z1.
# An estimator for the asymptotic variance of sqrt(n) times the sample moments in also computed. 
# INPUT PARAMETERS
#   upperset: Boolean indicating whether to test the moment in A_upper
#   arglist: A list of additional arguments passed, which must include
#         $bl_vals: An array of dimension 2*J*K*2. The second and third dimension correspond
#                   to support points of Z1 and Z2.  The first dimension is 1 if for y2==0 and
#                   is 2 if for y2==1.  The fourth dimension is 1 if the value is for the
#                   bl_minus function and 2 if for the bl_plus function.
#         $bu_vals: An 2*J*K*2 array similar to the above but for the bu function.
#         $bl_derivatives: a 6*2*J*K*2 array indicating derivatives for the bl function
#                   with respect to the population means of which they are functions.
#         $bu_derivatives: An analgous 6*2*J*K*2 array of derivatives for the bu function.
#         $svar_normalized_zeta_hat: a consistent estimator of the asymptotic variance of sqrt(n)*zeta_hat.
# OUTPUT PARAMETERS (as a list)
#   moments: The value of the sampel moments evaluated the input delta_value and zeta_hat
#   Sigma_hat: An estimator for the asymptotic variance of sqrt(n) times the sample moments computed 
#              by application of the delta method.
# NOTE: IMPLEMENTATION ONLY VALID FOR J=2.
#####################################################################################################
compute_nonempty_test_moments <- function(upperset, arglist) {
  cl_vals <- arglist$cl_vals[,,,upperset+1]
  cu_vals <- arglist$cu_vals[,,,upperset+1]
  cl_derivatives <- arglist$cl_derivatives[,,,,upperset+1]
  cu_derivatives <- arglist$cu_derivatives[,,,,upperset+1]
  J <- dim(cu_vals)[2]
  K <- dim(cu_vals)[3]
  moments <- rep(0,2*J*K*(K-1))
  # array of moment derivatives
  dmdz <- array(0,c(length(moments), dim(arglist$zeta_hat_array)))
  i = 0 # row counter
  for (k1 in 1:K) {
    for (k2 in 1:K) {
      if (k1 != k2) { # Include moments that do not involve b1, but that must be satisfied.
        for (j in 1:J) {
          i <- i + 1
          moments[i] <- cu_vals[1,j,k1] - cl_vals[1,j,k2]
          dmdz[i,,j,k1] <- cu_derivatives[,1,j,k1]
          dmdz[i,,j,k2] <- -cl_derivatives[,1,j,k2]
          i <- i + 1
          moments[i] <- cu_vals[2,j,k1] - cl_vals[2,j,k2]
          dmdz[i,,j,k1] <- cu_derivatives[,2,j,k1]
          dmdz[i,,j,k2] <- -cl_derivatives[,2,j,k2]
        }
      }
    }
  }
  dmdz_matrix <- matrix(dmdz, nrow = length(moments), ncol = 6*J*K)
  Sigma_hat <- dmdz_matrix %*% arglist$svar_normalized_zeta_hat %*% t(dmdz_matrix)
  return( list(moments=moments, Sigma_hat=Sigma_hat) )
}

################ Function compute_alpha_bounds ###############################################
# This function computes analog estites for bounds on alpha in the upper/lower set, as specified.
# Here alpha is the coefficient on the endogenous variable in an IV
# probit model with an included binary variable and an instrument taking K values.
# An estimator for the asymptotic variance of sqrt(n) times the sample moments in also computed. 
# INPUT PARAMETERS
#   upperset: Boolean indicating whether to test the moment in A_upper
#   arglist: A list of additional arguments passed, which must include
#         $bl_vals: An array of dimension 2*J*K*2. The second and third dimension correspond
#                   to support points of Z1 and Z2.  The first dimension is 1 if for y2==0 and
#                   is 2 if for y2==1.  The fourth dimension is 1 if the value is for the
#                   bl_minus function and 2 if for the bl_plus function.
#         $bu_vals: An 2*J*K*2 array similar to the above but for the bu function.
# OUTPUT PARAMETERS
#   alpha_bounds: A two vector with a lower bound and upper bound.
#####################################################################################################
compute_alpha_bounds <- function(upperset, arglist) {
  bl_vals <- arglist$bl_vals[,,,upperset+1]
  bu_vals <- arglist$bu_vals[,,,upperset+1]
  J <- dim(bu_vals)[2]
  K <- dim(bu_vals)[3]
  lower_bounds <- rep(0, J * K^2)
  upper_bounds <- rep(0, J * K^2)
  # array of moment derivatives
  i = 0 # row counter
  for (k1 in 1:K) {
    for (j in 1:J) {
      for (k2 in 1:K) { # Note the first arguments to bl_vals, bu_vals, and derivatives are offset by one due to array being indexed by one rather than zero
        i <- i + 1
        lower_bounds[i] <- bl_vals[2,j,k1] - bu_vals[1,j,k2]
        upper_bounds[i] <- bu_vals[2,j,k1] - bl_vals[1,j,k2]
      }
    }
  }
  return( c( max(lower_bounds), min(upper_bounds)) )
}

################ Function compute_beta0_bounds ###############################################
# This function computes analog estites for bounds on beta0 in the upper/lower set, as specified.
# Here alpha is the coefficient on the endogenous variable in an IV
# probit model with an included binary variable and an instrument taking K values.
# An estimator for the asymptotic variance of sqrt(n) times the sample moments in also computed. 
# INPUT PARAMETERS
#   upperset: Boolean indicating whether to test the moment in A_upper
#   arglist: A list of additional arguments passed, which must include
#         $bl_vals: An array of dimension 2*J*K*2. The second and third dimension correspond
#                   to support points of Z1 and Z2.  The first dimension is 1 if for y2==0 and
#                   is 2 if for y2==1.  The fourth dimension is 1 if the value is for the
#                   bl_minus function and 2 if for the bl_plus function.
#         $bu_vals: An 2*J*K*2 array similar to the above but for the bu function.
# OUTPUT PARAMETERS
#   beta0_bounds: A two vector with a lower bound and upper bound.
#####################################################################################################
compute_beta0_bounds <- function(upperset, arglist) {
  bl_vals <- arglist$bl_vals[,,,upperset+1]
  bu_vals <- arglist$bu_vals[,,,upperset+1]
  J <- dim(bu_vals)[2]
  K <- dim(bu_vals)[3]
  lower_bounds <- rep(0, K + K^3)
  upper_bounds <- rep(0, K + K^3)
  # array of moment derivatives
  i = 0 # row counter
  for (k1 in 1:K) {
    i <- i + 1
    lower_bounds[i] <- bl_vals[1,1,k1]
    upper_bounds[i] <- bu_vals[1,1,k1]
    for (k2 in 1:K) {
      for (k3 in 1:K) { # Note the first arguments to bl_vals, bu_vals, and derivatives are offset by one due to array being indexed by one rather than zero
        i <- i + 1
        lower_bounds[i] <- bl_vals[1,2,k1] + bl_vals[2,1,k2] - bu_vals[2,2,k3]
        upper_bounds[i] <- bu_vals[1,2,k1] + bu_vals[2,1,k2] - bl_vals[2,2,k3]
      }
    }
  }
  return( c( max(lower_bounds), min(upper_bounds)) )
}

################ Function compute_beta1_bounds ###############################################
# This function computes analog estites for bounds on beta1 in the upper/lower set, as specified.
# Here alpha is the coefficient on the endogenous variable in an IV
# probit model with an included binary variable and an instrument taking K values.
# An estimator for the asymptotic variance of sqrt(n) times the sample moments in also computed. 
# INPUT PARAMETERS
#   upperset: Boolean indicating whether to test the moment in A_upper
#   arglist: A list of additional arguments passed, which must include
#         $bl_vals: An array of dimension 2*J*K*2. The second and third dimension correspond
#                   to support points of Z1 and Z2.  The first dimension is 1 if for y2==0 and
#                   is 2 if for y2==1.  The fourth dimension is 1 if the value is for the
#                   bl_minus function and 2 if for the bl_plus function.
#         $bu_vals: An 2*J*K*2 array similar to the above but for the bu function.
# OUTPUT PARAMETERS
#   beta1_bounds: A two vector with a lower bound and upper bound.
#####################################################################################################
compute_beta1_bounds <- function(upperset, arglist) {
  bl_vals <- arglist$bl_vals[,,,upperset+1]
  bu_vals <- arglist$bu_vals[,,,upperset+1]
  J <- dim(bu_vals)[2]
  K <- dim(bu_vals)[3]
  lower_bounds <- rep(0, 2*K^2)
  upper_bounds <- rep(0, 2*K^2)
  i = 0 # row counter
  for (k1 in 1:K) {
    for (k2 in 1:K) {
      for (y2 in 1:2) { # Note the first arguments to bl_vals, bu_vals, and derivatives are offset by one due to array being indexed by one rather than zero
        i <- i + 1
        lower_bounds[i] <- bl_vals[y2,2,k1] - bu_vals[y2,1,k2]
        upper_bounds[i] <- bu_vals[y2,2,k1] - bl_vals[y2,1,k2]
      }
    }
  }
  return( c( max(lower_bounds), min(upper_bounds)) )
}

################ Function compute_DeltaZ1_bounds ###############################################
# This function computes analog estimates for bounds on Delta(z1) in the upper/lower set, as specified.
# Here alpha is the coefficient on the endogenous variable in an IV
# probit model with an included binary variable and an instrument taking K values.
# An estimator for the asymptotic variance of sqrt(n) times the sample moments in also computed. 
# INPUT PARAMETERS
#   upperset: Boolean indicating whether to test the moment in A_upper
#   arglist: A list of additional arguments passed, which must include
#         $bl_vals: An array of dimension 2*J*K*2. The second and third dimension correspond
#                   to support points of Z1 and Z2.  The first dimension is 1 if for y2==0 and
#                   is 2 if for y2==1.  The fourth dimension is 1 if the value is for the
#                   bl_minus function and 2 if for the bl_plus function.
#         $bu_vals: An 2*J*K*2 array similar to the above but for the bu function.
# OUTPUT PARAMETERS
#   bounds: A two vector with a lower bound and upper bound.
#####################################################################################################
compute_DeltaZ1_bounds <- function(z1, upperset, arglist) {
  cl_vals <- arglist$cl_vals[,,,upperset+1]
  cu_vals <- arglist$cu_vals[,,,upperset+1]
  K <- dim(cu_vals)[3]
  j <- z1 + 1 # offset by one for indexing by 1
  lower_bounds <- rep(0, K^2)
  upper_bounds <- rep(0, K^2)
  i = 0 # row counter
  for (k1 in 1:K) {
    for (k2 in 1:K) {
      i <- i + 1
      lower_bounds[i] <- cl_vals[1,j,k1] - cu_vals[2,j,k2]
      upper_bounds[i] <- cu_vals[1,j,k1] - cl_vals[2,j,k2]
    }
  }
  return( c( max(lower_bounds), min(upper_bounds)) )
}

