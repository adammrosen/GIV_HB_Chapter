# Analysis of Angrist Evans (1998) data for the Handbook Chapter "Generalized Instrumental Variables Models, Methods, and Applications"
# This code produces results reported in Tables 3-5.

rm(list=ls())

set.seed(987698764)

# Which one of the following three lines is NOT commented determines which instrument(s) is/are used.
# instrument_case = "T" # twins instrument. Uncommenting this line while commenting the next two will produce the results reported in Table 3.
# instrument_case = "SS" # same sex instrument. Uncommenting this line while commenting the previous one and the next one will produce the results reported in Table 4.
 instrument_case = "SST" # same sex and twins instruments together. Uncommenting this line while commenting the previous two will produce the results reported in Table 5.

# MODIFY PATH ACCORDINGLY AS NEEDED 
replication_files_folder <- "/Users/amr331/Dropbox/GIV/Handbook/Replication Files/" # Set as approriate for local directory structure
path <- paste(replication_files_folder, "Section 8.2/", sep="")
setwd(path)

if (!require("mvtnorm")) install.packages("mvtnorm")                         
library(mvtnorm)
if (!require("nloptr")) install.packages("nloptr")
library(nloptr)
if (!require("prodlim")) install.packages("prodlim")
library(prodlim)

source("Inference_Functions_NO_Z1.R")
source("CLR_Functions.R")

# load data
pums80 <- read.table("https://dataverse.harvard.edu/api/access/datafile/:persistentId?persistentId=doi:10.7910/DVN/8RYANI/HKEUEN",
                     sep="\t", header=TRUE)

######################## CREATE VARIABLES ######################################################
Y1 <- pums80$workedm
Y2 <- pums80$morekids
Z2 <- pums80$samesex
Z3 <- pums80$multi2nd
###########################################################################################################

#### Set Instrument ##################################################
if (instrument_case == "SS") { # Use same sex instrument
    idx <- (Z3 == 0)
    Y1 <- Y1[idx]
    Y2 <- Y2[idx]
    # Z = 0 for not twins, not same sex
    # Z = 1 for not twins, same sex
    Zmatrix <- matrix(Z2[idx], ncol=1)
    instrument_descrip <- "SAME SEX"
} else if (instrument_case == "T") { # Use twins instrument
    # Z = 0 for not twins
    # Z = 1 for twins
    Zmatrix <- matrix(Z3, ncol=1)
    instrument_descrip <- "TWINS"
} else { # Use both twins and same sex instruments
    # Z = 0 for not twins, not same sex
    # Z = 1 for not twins, same sex
    # Z = 2 for twins
    instrument_case = "SST"
    Zmatrix <- matrix((1-Z3)*Z2 + 2*Z3, ncol=1)
    instrument_descrip <- "TWINS AND SAME SEX"
}
N = length(Y1)
Zsupport <- as.matrix(unique(Zmatrix))
Zsupport <- as.matrix(Zsupport[order(Zsupport)])
nSupportZ <- dim(Zsupport)[1]
Zsupport_indices <- matrix(0,nrow=N,ncol=1) # This N*1 matrix indicates which of the ordered support
# points correspond to observation i.
# Generate unique numerical indices for each point of support
for(i in 1:N) {
  Zsupport_indices[i,1] <- row.match(Zmatrix[i,],Zsupport)
}
#############################################################################

####### Create variable for support of Y and indicators for certain realizations need for forming conditional moments ####
Ysupport <- rbind(c(0,0),c(0,1),c(1,0),c(1,1))
Yindicators <- cbind((Y1==0) & (Y2==0), (Y1==0) & (Y2==1), !((Y1==1) & (Y2==0)), !((Y1==1) & (Y2==1)), (Y1==0))
Yindicators_zeta <- cbind(1,Yindicators[,c(1,5,4,3,2)]) # rearrange rows into order used in defining components of zeta_hat
# indicators for (0,0),(0,1),!(1,0),!(1,1),(0,.)
############################################################################################################

################ Create indicators for binning of conditioning variables #############################
Z_indicators = matrix(0,nrow=N,ncol=nSupportZ)
for (i in 1:nSupportZ) {
  Z_indicators[,i] = (Zsupport_indices == i)
}
###########################################################################################################

####### Compute probabilities and g sets conditional on Z ######################################
fy_z <- matrix(0,nrow=nSupportZ,ncol=5)
colnames(fy_z) <- c("(0,0)","(0,1)","!(1,0)","!(1,1)","(0,.)")
rownames(fy_z) <- Zsupport
upper_gset <- matrix(0,nrow=nSupportZ,ncol=4)
colnames(upper_gset) <- c("g0-LB","g0-UB","g1-LB","g1-UB")
rownames(upper_gset) <- Zsupport
lower_gset <- matrix(0,nrow=nSupportZ,ncol=4)
colnames(lower_gset) <- c("g0-LB","g0-UB","g1-LB","g1-UB")
rownames(lower_gset) <- Zsupport

Zcount <- rep(0,nSupportZ)
for (i in 1:nSupportZ) {
  # Compute conditional probabilities
  Zcount[i] <- sum(Zsupport_indices == i)
  for (j in 1:dim(Yindicators)[2]) {
    fy_z[i,j] <- sum((Zsupport_indices == i) * (Yindicators[,j])) / Zcount[i]
  }
}

################# Compute bounds and standard errors for the upper gset ########################
upper_gset[,1] <- fy_z[,1]
upper_gset[,2] <- fy_z[,5]
upper_gset[,3] <- fy_z[,5]
upper_gset[,4] <- fy_z[,4]
upper_gset_se <- sqrt((upper_gset*(1-upper_gset))/matrix(Zcount,nrow=nSupportZ,ncol=4))

# Take intersections over z
upper_gset_g0_lower_bound <- max(upper_gset[,1])
upper_gset_g0_upper_bound <- min(upper_gset[,2])
upper_gset_g1_lower_bound <- max(upper_gset[,3])
upper_gset_g1_upper_bound <- min(upper_gset[,4])

# Compute lower and upper bounds on delta, not accounting for possibility that the set is empty
upper_dset_lower_bound <- upper_gset_g0_lower_bound - upper_gset_g1_upper_bound
upper_dset_upper_bound <- upper_gset_g0_upper_bound - upper_gset_g1_lower_bound

upper_gset_isempty <- (upper_gset_g0_lower_bound > upper_gset_g0_upper_bound) | (upper_gset_g1_lower_bound > upper_gset_g1_upper_bound)

################## Compute bounds and standard errors for the lower gset #########################
lower_gset[,1] <- fy_z[,5]
lower_gset[,2] <- fy_z[,3]
lower_gset[,3] <- fy_z[,2]
lower_gset[,4] <- fy_z[,5]
lower_gset_se <- sqrt((lower_gset*(1-lower_gset))/matrix(Zcount,nrow=nSupportZ,ncol=4))

# Take intersections over z
lower_gset_g0_lower_bound <- max(lower_gset[,1])
lower_gset_g0_upper_bound <- min(lower_gset[,2])
lower_gset_g1_lower_bound <- max(lower_gset[,3])
lower_gset_g1_upper_bound <- min(lower_gset[,4])

# Compute lower and upper bounds on delta, not accounting for possibility that the set is empty
lower_dset_lower_bound <- lower_gset_g0_lower_bound - lower_gset_g1_upper_bound
lower_dset_upper_bound <- lower_gset_g0_upper_bound - lower_gset_g1_lower_bound

lower_gset_isempty <- (lower_gset_g0_lower_bound > lower_gset_g0_upper_bound) | (lower_gset_g1_lower_bound > lower_gset_g1_upper_bound)
###############################################################################################


##### Estimate Sample Moments for Parametric Treatment of Moment Functions ######################
zeta_indicators <- matrix(0, nrow=N, ncol = 6*nSupportZ)
for (j in 0:(nSupportZ-1)) {
  zeta_idx <- j * 6 + 1
  zeta_indicators[,zeta_idx:(zeta_idx + 5)] = matrix((Zsupport_indices == (j+1)), nrow=N, ncol=6) * Yindicators_zeta
}

zeta_hat <- colMeans(zeta_indicators)
svar_normalized_zeta_hat <- var(zeta_indicators)
arglist <- list(zeta_hat=zeta_hat, svar_normalized_zeta_hat = svar_normalized_zeta_hat, N=N)
###################################################################################################


################### Set parameters for Inference ##################################################
alpha <- 0.05
stepsize <- 0.0001
arglist$LB <- -1
arglist$UB <- 1
###################################################################################################

############ FUNCTION DEFINITIONS FOR INTERSECTION BOUND TESTS ##################################################

######## Function CLR_Test_g0_upper #############################################################################
# This function computes the moments needed to test whether g0 is in the identified set corresponding
# to the case g(0) <= g(1) and then calls CLR_Test to test whether or not the moment inequalities are satisfied.
#################################################################################################################
CLR_Test_g0_upper <- function(g0,alpha=0.05,arglist) {
  result <- compute_g0_moments_upper(g0=g0, b=arglist$zeta_hat, svar_normalized_zeta_hat = arglist$svar_normalized_zeta_hat)
  return(CLR_Test(moment_estimates = result$moments, V = result$Sigma_hat/N, N = arglist$N, alpha = alpha))
}

######## Function CLR_Test_g1_upper #############################################################################
# This function computes the moments needed to test whether g1 is in the identified set corresponding
# to the case g(0) <= g(1) and then calls CLR_Test to test whether or not the moment inequalities are satisfied.
#################################################################################################################
CLR_Test_g1_upper <- function(g1,alpha=0.05,arglist) {
  result <- compute_g1_moments_upper(g1=g1, b=arglist$zeta_hat, svar_normalized_zeta_hat = arglist$svar_normalized_zeta_hat)
  return(CLR_Test(moment_estimates = result$moments, V = result$Sigma_hat/N, N = arglist$N, alpha = alpha))
}

######## Function CLR_Test_g0_lower #############################################################################
# This function computes the moments needed to test whether g0 is in the identified set corresponding
# to the case g(0) >= g(1) and then calls CLR_Test to test whether or not the moment inequalities are satisfied.
#################################################################################################################
CLR_Test_g0_lower <- function(g0,alpha=0.05,arglist) {
  result <- compute_g0_moments_lower(g0=g0, b=arglist$zeta_hat, svar_normalized_zeta_hat = arglist$svar_normalized_zeta_hat)
  return(CLR_Test(moment_estimates = result$moments, V = result$Sigma_hat/N, N = arglist$N, alpha = alpha))
}

######## Function CLR_Test_g1_lower #############################################################################
# This function computes the moments needed to test whether g1 is in the identified set corresponding
# to the case g(0) >= g(1) and then calls CLR_Test to test whether or not the moment inequalities are satisfied.
#################################################################################################################
CLR_Test_g1_lower <- function(g1,alpha=0.05,arglist) {
  result <- compute_g1_moments_lower(g1=g1, b=arglist$zeta_hat, svar_normalized_zeta_hat = arglist$svar_normalized_zeta_hat)
  return(CLR_Test(moment_estimates = result$moments, V = result$Sigma_hat/N, N = arglist$N, alpha = alpha))
}

######## Function CLR_Test_deltavals_upper #############################################################################
# This function computes the moments needed to test whether delta = g(0)-g(1) is in the identified set corresponding
# to the case g(0) <= g(1) and then calls CLR_Test to test whether or not the moment inequalities are satisfied.
#################################################################################################################
CLR_Test_deltavals_upper <- function(delta_value, alpha = 0.05, arglist) {
  result <- compute_delta_moments_upper(dv = delta_value,
                                        b = arglist$zeta_hat, svar_normalized_zeta_hat = arglist$svar_normalized_zeta_hat)
  return(CLR_Test(moment_estimates = result$moments, V = result$Sigma_hat/N, N = N, alpha = alpha))
}

######## Function CLR_Test_deltavals_lower #############################################################################
# This function computes the moments needed to test whether delta = g(0)-g(1) is in the identified set corresponding
# to the case g(0) >= g(1) and then calls CLR_Test to test whether or not the moment inequalities are satisfied.
#################################################################################################################
CLR_Test_deltavals_lower <- function(delta_value, alpha = 0.05, arglist) {
  result <- compute_delta_moments_lower(dv = delta_value,
                                        b = arglist$zeta_hat, svar_normalized_zeta_hat = arglist$svar_normalized_zeta_hat)
  return(CLR_Test(moment_estimates = result$moments, V = result$Sigma_hat/N, N = N, alpha = alpha))
}

######## Function CLR_Test_deltavals_upper #############################################################################
# This function computes the moments needed to test whether the set of (g(0),g(1)) with g(0) <= g(1) is nonempty
# and then calls CLR_Test to test whether or not the moment inequalities are satisfied.
#################################################################################################################
CLR_Test_upper_set_nonempty <- function(alpha=0.05, arglist) {
  result <- compute_lower_set_test_moments(b = arglist$zeta_hat,
                                           svar_normalized_zeta_hat = arglist$svar_normalized_zeta_hat)
  return(CLR_Test(moment_estimates = result$moments, V = result$Sigma_hat/N, N = N, alpha = alpha))
}

######## Function CLR_Test_deltavals_lower #############################################################################
# This function computes the moments needed to test whether the set of (g(0),g(1)) with g(0) >= g(1) is nonempty
# and then calls CLR_Test to test whether or not the moment inequalities are satisfied.
#################################################################################################################
CLR_Test_lower_set_nonempty <- function(alpha=0.05, arglist) {
  result <- compute_lower_set_test_moments(b = arglist$zeta_hat,
                                           svar_normalized_zeta_hat = arglist$svar_normalized_zeta_hat)
  return(CLR_Test(moment_estimates = result$moments, V = result$Sigma_hat/N, N = N, alpha = alpha))
}

###### COMPUTE 0.95 CONFIDENCE INTERVALS FOR g(0) AND g(1) FOR THE CASE g(0) <= g(1) ##############
if (upper_gset_isempty) { 
  # Initialize test grids and precision-corrected minimum moment values
  upper_g0_test_grid <- cbind(seq(upper_gset_g0_lower_bound, upper_gset_g0_upper_bound, stepsize), Inf)
  upper_g1_test_grid <- cbind(seq(upper_gset_g1_lower_bound, upper_gset_g1_upper_bound, stepsize), Inf)
  upper_delta_test_grid <- cbind(seq(upper_dset_lower_bound, upper_dset_upper_bound, stepsize), Inf)
  for (i in (1:dim(upper_g0_test_grid)[1])) {
    upper_g0_test_grid[i,2] <- CLR_Test_g0_upper(g0 = upper_g0_test_grid[i,1], alpha = alpha, arglist = arglist)$pcorrected_min
  }
  for (i in (1:dim(upper_g1_test_grid)[1])) {
    upper_g1_test_grid[i,2] <- CLR_Test_g1_upper(g1 = upper_g1_test_grid[i,1], alpha = alpha, arglist = arglist)$pcorrected_min
  }
  for (i in (1:dim(upper_delta_test_grid)[1])) {
    upper_delta_test_grid[i,2] <- CLR_Test_deltavals_upper(delta_value = upper_delta_test_grid[i,1], alpha = alpha, arglist = arglist)$pcorrected_min
  }
} else {
  upper_gset_g0_LB_med_corrected <- find_CI_bound(bound=upper_gset_g0_lower_bound, isLower = T, alpha = 0.5,
                                    stepsize = stepsize, clrTestFun = CLR_Test_g0_upper, arglist = arglist, stop_val = 0)
  upper_gset_g0_UB_med_corrected <- find_CI_bound(bound=upper_gset_g0_upper_bound, isLower = F, alpha = 0.5,
                                    stepsize = stepsize, clrTestFun = CLR_Test_g0_upper, arglist = arglist, stop_val = 1)
  upper_gset_g1_LB_med_corrected <- find_CI_bound(bound=upper_gset_g1_lower_bound, isLower = T, alpha = 0.5,
                                    stepsize = stepsize, clrTestFun = CLR_Test_g1_upper, arglist = arglist, stop_val = 0)
  upper_gset_g1_UB_med_corrected <- find_CI_bound(bound=upper_gset_g1_upper_bound, isLower = F, alpha = 0.5,
                                    stepsize = stepsize, clrTestFun = CLR_Test_g1_upper, arglist = arglist, stop_val = 1)
  upper_set_delta_LB_med_corrected <- find_CI_bound(bound = upper_dset_lower_bound, isLower = T, alpha = 0.5, stepsize = stepsize, clrTestFun = CLR_Test_deltavals_upper, arglist = arglist, stop_val = -1)
  upper_set_delta_UB_med_corrected <- find_CI_bound(bound = upper_dset_upper_bound, isLower = F, alpha = 0.5, stepsize = stepsize, clrTestFun = CLR_Test_deltavals_upper, arglist = arglist, stop_val = 0)
  
  upper_gset_g0_CI_LB_95 <- find_CI_bound(bound=upper_gset_g0_lower_bound, isLower = T, alpha = alpha,
                            stepsize = stepsize, clrTestFun = CLR_Test_g0_upper, arglist = arglist, stop_val = 0)
  upper_gset_g0_CI_UB_95 <- find_CI_bound(bound=upper_gset_g0_upper_bound, isLower = F, alpha = alpha,
                            stepsize = stepsize, clrTestFun = CLR_Test_g0_upper, arglist = arglist, stop_val = 1)
  upper_gset_g1_CI_LB_95 <- find_CI_bound(bound=upper_gset_g1_lower_bound, isLower = T, alpha = alpha,
                            stepsize = stepsize, clrTestFun = CLR_Test_g1_upper, arglist = arglist, stop_val = 0)
  upper_gset_g1_CI_UB_95 <- find_CI_bound(bound=upper_gset_g1_upper_bound, isLower = F, alpha = alpha,
                            stepsize = stepsize, clrTestFun = CLR_Test_g1_upper, arglist = arglist, stop_val = 1)
  upper_set_delta_CI_LB <- find_CI_bound(bound = upper_dset_lower_bound, isLower = T, alpha = alpha, stepsize = stepsize, clrTestFun = CLR_Test_deltavals_upper, arglist = arglist, stop_val = -1) 
  upper_set_delta_CI_UB <- find_CI_bound(bound = upper_dset_upper_bound, isLower = F, alpha = alpha, stepsize = stepsize, clrTestFun = CLR_Test_deltavals_upper, arglist = arglist, stop_val = 0) 
  }
#########################################################################################################

###### COMPUTE 0.95 CONFIDENCE INTERVALS FOR g(0) AND g(1) FOR THE CASE g(0) >= g(1) ##############
if (lower_gset_isempty) { 
  # Initialize test grids and precision-corrected minimum moment values
  stepsgn <- sign(lower_gset_g0_upper_bound-lower_gset_g0_lower_bound)
  lower_g0_test_grid <- cbind(seq(lower_gset_g0_lower_bound, lower_gset_g0_upper_bound, stepsgn * stepsize), Inf)
  
  stepsgn <- sign(lower_gset_g1_upper_bound-lower_gset_g1_lower_bound)
  lower_g1_test_grid <- cbind(seq(lower_gset_g1_lower_bound, lower_gset_g1_upper_bound, stepsgn * stepsize), Inf)
  
  stepsgn <- sign(lower_dset_upper_bound-lower_dset_lower_bound)
  lower_delta_test_grid <- cbind(seq(lower_dset_lower_bound, lower_dset_upper_bound, stepsgn * stepsize), Inf)
  
  for (i in (1:dim(lower_g0_test_grid)[1])) {
    lower_g0_test_grid[i,2] <- CLR_Test_g0_lower(g0 = lower_g0_test_grid[i,1], alpha = alpha, arglist = arglist)$pcorrected_min
  }
  for (i in (1:dim(lower_g1_test_grid)[1])) {
    lower_g1_test_grid[i,2] <- CLR_Test_g1_lower(g1 = lower_g1_test_grid[i,1], alpha = alpha, arglist = arglist)$pcorrected_min
  }
  for (i in (1:dim(lower_delta_test_grid)[1])) {
    lower_delta_test_grid[i,2] <- CLR_Test_deltavals_lower(delta_value = lower_delta_test_grid[i,1], alpha = alpha, arglist = arglist)$pcorrected_min
  }
} else {
  lower_gset_g0_LB_med_corrected <- find_CI_bound(bound=lower_gset_g0_lower_bound, isLower = T, alpha = 0.5,
                                    stepsize = stepsize, clrTestFun = CLR_Test_g0_lower, arglist = arglist, stop_val = 0)
  
  lower_gset_g0_UB_med_corrected <- find_CI_bound(bound=lower_gset_g0_upper_bound, isLower = F, alpha = 0.5,
                                    stepsize = stepsize, clrTestFun = CLR_Test_g0_lower, arglist = arglist, stop_val = 1)
  
  lower_gset_g1_LB_med_corrected <- find_CI_bound(bound=lower_gset_g1_lower_bound, isLower = T, alpha = 0.5,
                                    stepsize = stepsize, clrTestFun = CLR_Test_g1_lower, arglist = arglist, stop_val = 0)
  
  lower_gset_g1_UB_med_corrected <- find_CI_bound(bound=lower_gset_g1_upper_bound, isLower = F, alpha = 0.5,
                                    stepsize = stepsize, clrTestFun = CLR_Test_g1_lower, arglist = arglist, stop_val = 1)
  lower_set_delta_LB_med_corrected <- find_CI_bound(bound = lower_dset_lower_bound, isLower = T, alpha = 0.5, stepsize = stepsize, clrTestFun = CLR_Test_deltavals_lower, arglist = arglist, stop_val = 0) 
  lower_set_delta_UB_med_corrected <- find_CI_bound(bound = lower_dset_upper_bound, isLower = F, alpha = 0.5, stepsize = stepsize, clrTestFun = CLR_Test_deltavals_lower, arglist = arglist, stop_val = 1) 

  lower_gset_g0_CI_LB_95 <- find_CI_bound(bound=lower_gset_g0_lower_bound, isLower = T, alpha = alpha,
                            stepsize = stepsize, clrTestFun = CLR_Test_g0_lower, arglist = arglist, stop_val = 0)
  lower_gset_g0_CI_UB_95 <- find_CI_bound(bound=lower_gset_g0_upper_bound, isLower = F, alpha = alpha,
                            stepsize = stepsize, clrTestFun = CLR_Test_g0_lower, arglist = arglist, stop_val = 1)
  lower_gset_g1_CI_LB_95 <- find_CI_bound(bound=lower_gset_g1_lower_bound, isLower = T, alpha = alpha,
                            stepsize = stepsize, clrTestFun = CLR_Test_g1_lower, arglist = arglist, stop_val = 0)
  lower_gset_g1_CI_UB_95 <- find_CI_bound(bound=lower_gset_g1_upper_bound, isLower = F, alpha = alpha,
                            stepsize = stepsize, clrTestFun = CLR_Test_g1_lower, arglist = arglist, stop_val = 1)
  lower_set_delta_CI_LB <- find_CI_bound(bound = lower_dset_lower_bound, isLower = T, alpha = alpha, stepsize = stepsize, clrTestFun = CLR_Test_deltavals_lower, arglist = arglist, stop_val = 0) 
  lower_set_delta_CI_UB <- find_CI_bound(bound = lower_dset_upper_bound, isLower = F, alpha = alpha, stepsize = stepsize, clrTestFun = CLR_Test_deltavals_lower, arglist = arglist, stop_val = 1) 
}
#########################################################################################################

reject_upper_gset_inequalities = F
# If the analog estimator for the set with g(0) > g(1) is empty, test whether the inequalities that define the set admit a solution.
if (upper_gset_isempty) {
  pcorrected_minimum_inequality <- CLR_Test_upper_set_nonempty(alpha = alpha, arglist = arglist)$pcorrected_min
  reject_upper_gset_inequalities <- (pcorrected_minimum_inequality < 0)
}

reject_lower_gset_inequalities = F
# If the analog estimator for the set with g(0) > g(1) is empty, test whether the inequalities that define the set admit a solution.
if (lower_gset_isempty) {
  pcorrected_minimum_inequality <- CLR_Test_lower_set_nonempty(alpha = alpha, arglist = arglist)$pcorrected_min
  reject_lower_gset_inequalities <- (pcorrected_minimum_inequality < 0)
}

#######################################################################################


###### DISPLAY OUTPUT ###############
sink(paste("Inference_with_", instrument_case, "_Instruments_No_Included_Regressors.txt", sep=""))
cat(" -- NO COVARIATES,", instrument_descrip, " INSTRUMENT -- \n", sep="")
cat("================================ \n \n ")
cat(" ---- g(0) and g(1) bound estimates for the case where g(0) <= g(1) ---- \n")
cat(capture.output(upper_gset), sep = "\n")
cat("\n")
cat(" ---- Standard errors of bound estimates for the case where g(0) <= g(1) ---- \n")
cat(capture.output(upper_gset_se), sep = "\n")
cat("\n")
if (upper_gset_isempty) { cat("The analog set of g(0), g(1) pairs with g(0) < g(1) is empty. \n ")
} else {
  cat("Median corrected bound estimates for g(0): [", upper_gset_g0_LB_med_corrected, ",", upper_gset_g0_UB_med_corrected, "]\n" )
  cat("Median corrected bound estimates for g(1): [", upper_gset_g1_LB_med_corrected, ",", upper_gset_g1_UB_med_corrected, "]\n" )
  cat("Median corrected bound estimates for Delta = g(0)-g(1): [", upper_set_delta_LB_med_corrected, ",", upper_set_delta_UB_med_corrected, "]\n" )
  cat("95% confidence interval for g(0): [", upper_gset_g0_CI_LB_95, ",", upper_gset_g0_CI_UB_95, "]\n" )
  cat("95% confidence interval for g(1): [", upper_gset_g1_CI_LB_95, ",", upper_gset_g1_CI_UB_95, "]\n" )
  cat("95% confidence interval for Delta = g(0)-g(1): [", upper_set_delta_CI_LB, ",", upper_set_delta_CI_UB, "]\n" )
}
cat("================================ \n \n ")
cat(" ---- g(0) and g(1) bound estimates for the case where g(0) >= g(1) ---- \n")
cat(capture.output(lower_gset), sep = "\n")
cat("\n")
cat(" ---- Standard errors of bound estimates for the case where g(0) >= g(1) ---- \n")
cat(capture.output(lower_gset_se), sep = "\n")
cat("\n")
if (lower_gset_isempty) {
  if ((max(lower_g0_test_grid[,2]) < 0) & (max(lower_g1_test_grid[,2]) < 0) & (max(lower_delta_test_grid[,2]) < 0)) { 
      cat("The analog set of g(0), g(1) pairs with g(0) >= g(1) is empty. \n")
  if (reject_lower_gset_inequalities) cat("The hypothesis that the set of g(0), g(1) pairs with g(0) >= g(1) is nonempty is rejected at level ", alpha, "\n", sep ="")
  }
} else {
  cat("Median corrected bound estimates for g(0): [", lower_gset_g0_LB_med_corrected, ",", lower_gset_g0_UB_med_corrected, "]\n" )
  cat("Median corrected bound estimates for g(1): [", lower_gset_g1_LB_med_corrected, ",", lower_gset_g1_UB_med_corrected, "]\n" )
  cat("Median corrected bound estimates for Delta = g(0)-g(1): [", lower_set_delta_LB_med_corrected, ",", lower_set_delta_UB_med_corrected, "]\n" )
  cat("95% confidence interval for g(0): [", lower_gset_g0_CI_LB_95, ",", lower_gset_g0_CI_UB_95, "]\n" )
  cat("95% confidence interval for g(1): [", lower_gset_g1_CI_LB_95, ",", lower_gset_g1_CI_UB_95, "]\n" )
  cat("95% confidence interval for Delta = g(0)-g(1): [", lower_set_delta_CI_LB, ",", lower_set_delta_CI_UB, "]\n" )
}
sink()
#############################################
