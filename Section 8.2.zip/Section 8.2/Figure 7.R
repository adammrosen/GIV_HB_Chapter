# Analysis of Angrist Evans (1998) data for the Handbook chapter "Generalized Instrumental Variable Models, Methods, and Applications."
# This file draws Figure 7.

# define path to directories where files (graphics) will be written and from which data will be read.

#writepath = "/Users/andrew/Dropbox/GIV/Handbook/Replication Files/Section 8.2/OUTPUT/" # Cambridge iMac
writepath = "/Users/amr331/Dropbox/GIV/Handbook/Replication Files/WorkingDirectory/OUTPUT/" # Adam's MacBook

pums80 <- read.table("https://dataverse.harvard.edu/api/access/datafile/:persistentId?persistentId=doi:10.7910/DVN/8RYANI/HKEUEN",
                     sep="\t", header=TRUE)


# fij calculates estimated probabilities of y variables for cells defined by values of zvariables
# arguments "yvariables" and "zvariables" are ignored and the required variable names are hard coded.

fij = function(yvariables = list("workedm","morekids"),zvariables = list("samesex","multi2nd"),pumsdata = pums80) {
  answer = matrix(NA,ncol = 4 + 2 +1,nrow = 2*2)
  count = 0
  for (ss in 0:1) {
    for (mb in 0:1) {
      count = count + 1
      num = sum(pumsdata$samesex == ss & pumsdata$multi2nd == mb)
      f00 = sum(pumsdata$samesex == ss & pumsdata$multi2nd == mb & pumsdata$workedm == 0 & pumsdata$morekids == 0)/num
      f01 = sum(pumsdata$samesex == ss & pumsdata$multi2nd == mb & pumsdata$workedm == 0 & pumsdata$morekids == 1)/num
      f10 = sum(pumsdata$samesex == ss & pumsdata$multi2nd == mb & pumsdata$workedm == 1 & pumsdata$morekids == 0)/num
      f11 = sum(pumsdata$samesex == ss & pumsdata$multi2nd == mb & pumsdata$workedm == 1 & pumsdata$morekids == 1)/num
      answer[count,] = c(f00,f01,f10,f11,ss,mb,num)
    }
  }
  return(answer)
}
probs80 = fij()


# samesex instrument alone rows 1+2 vs 3+4 (but really 1 vs 3 since samesex has no meaning when multi2nd = 1)
# multi2nd instrument alone rows 1+3 vs 2+4
# samesex and multi2nd rows 2+4 vs 1 vs 3 (only 3 points of support for reason above)

# calculations using the same-sex instrument alone
sscalc = function(probs,eps = 1e-8) { 
  # does not use twins birth mothers
  f00_0 = probs[1,1]; f01_0 = probs[1,2]; f10_0 = probs[1,3]; f11_0 = probs[1,4]
  f00_1 = probs[3,1]; f01_1 = probs[3,2]; f10_1 = probs[3,3]; f11_1 = probs[3,4]
  
  incempty = FALSE
  inc_up_g0 = min(f00_0 + f01_0 , f00_1 + f01_1)
  inc_lo_g0 = max(f00_0 , f00_1)
  inc_up_g1 = min(1-f11_0 , 1-f11_1)
  inc_lo_g1 = max(f00_0 + f01_0 , f00_1 + f01_1)
  if(inc_up_g0 < inc_lo_g0-eps || inc_up_g1 < inc_lo_g1-eps) {incempty = TRUE}
  
  decempty = FALSE
  dec_up_g0 = min(1 - f10_0 , 1 -  f10_1)
  dec_lo_g0 = max(f00_0 + f01_0 , f00_1 + f01_1)
  dec_up_g1 = min(f00_0 + f01_0 , f00_1 + f01_1)
  dec_lo_g1 = max(f01_0 , f01_1)
  if(dec_up_g0 < dec_lo_g0 -eps|| dec_up_g1 < dec_lo_g1-eps) {decempty = TRUE}
  
  
  inc = rbind(c(inc_up_g0,inc_lo_g0),c(inc_up_g1,inc_lo_g1))
  dec = rbind(c(dec_up_g0,dec_lo_g0),c(dec_up_g1,dec_lo_g1))
  
  inc_up_g0mg1 = inc[1,1] - inc[2,2]
  inc_lo_g0mg1 = inc[1,2] - inc[2,1]
  dec_up_g0mg1 = dec[1,1] - dec[2,2]
  dec_lo_g0mg1 = dec[1,2] - dec[2,1]
  
  
  inc_g0mg1 = c(inc_up_g0mg1,inc_lo_g0mg1)
  dec_g0mg1 = c(dec_up_g0mg1,dec_lo_g0mg1)
  
  if (incempty) {inc = NA; inc_g0mg1 = NA}
  if (decempty) {dec = NA; dec_g0mg1 = NA}
  
  return(list(inc = inc, dec = dec, inc_g0mg1= inc_g0mg1, dec_g0mg1 = dec_g0mg1 , incempty = incempty, decempty = decempty))
}

ssresult = sscalc(probs80)

#calculations using the twins instrument alone
twcalc = function(probs,eps = 1e-8) { 
  # twins instrument - use all mothers
  # NOTE set for decreasing g function is empty!
  numtw0 = probs[1,7] + probs[3,7]
  numtw1 = probs[2,7] + probs[4,7]
  
  f00_0 = (probs[1,1]*probs[1,7] + probs[3,1]*probs[3,7])/numtw0
  f01_0 = (probs[1,2]*probs[1,7] + probs[3,2]*probs[3,7])/numtw0
  f10_0 = (probs[1,3]*probs[1,7] + probs[3,3]*probs[3,7])/numtw0
  f11_0 = (probs[1,4]*probs[1,7] + probs[3,4]*probs[3,7])/numtw0
  
  f00_1 = (probs[2,1]*probs[2,7] + probs[4,1]*probs[4,7])/numtw1
  f01_1 = (probs[2,2]*probs[2,7] + probs[4,2]*probs[4,7])/numtw1
  f10_1 = (probs[2,3]*probs[2,7] + probs[4,3]*probs[4,7])/numtw1
  f11_1 = (probs[2,4]*probs[2,7] + probs[4,4]*probs[4,7])/numtw1
  
  incempty = FALSE
  inc_up_g0 = min(f00_0 + f01_0 , f00_1 + f01_1)
  inc_lo_g0 = max(f00_0 , f00_1)
  inc_up_g1 = min(1-f11_0 , 1-f11_1)
  inc_lo_g1 = max(f00_0 + f01_0 , f00_1 + f01_1)
  if(inc_up_g0 < inc_lo_g0-eps || inc_up_g1 < inc_lo_g1-eps) {incempty = TRUE}
  
  decempty = FALSE
  dec_up_g0 = min(1 - f10_0 , 1 -  f10_1)
  dec_lo_g0 = max(f00_0 + f01_0 , f00_1 + f01_1)
  dec_up_g1 = min(f00_0 + f01_0 , f00_1 + f01_1)
  dec_lo_g1 = max(f01_0 , f01_1)
  if(dec_up_g0 < dec_lo_g0 -eps|| dec_up_g1 < dec_lo_g1-eps) {decempty = TRUE}
  
  
  inc = rbind(c(inc_up_g0,inc_lo_g0),c(inc_up_g1,inc_lo_g1))
  dec = rbind(c(dec_up_g0,dec_lo_g0),c(dec_up_g1,dec_lo_g1))
  
  inc_up_g0mg1 = inc[1,1] - inc[2,2]
  inc_lo_g0mg1 = inc[1,2] - inc[2,1]
  dec_up_g0mg1 = dec[1,1] - dec[2,2]
  dec_lo_g0mg1 = dec[1,2] - dec[2,1]
  
  
  inc_g0mg1 = c(inc_up_g0mg1,inc_lo_g0mg1)
  dec_g0mg1 = c(dec_up_g0mg1,dec_lo_g0mg1)
  
  if (incempty) {inc = NA; inc_g0mg1 = NA}
  if (decempty) {dec = NA; dec_g0mg1 = NA}
  
  return(list(inc = inc, dec = dec, inc_g0mg1= inc_g0mg1, dec_g0mg1 = dec_g0mg1 , incempty = incempty, decempty = decempty))
}

twresult = twcalc(probs80)

# calculations using the same-sex and twins instrument
sstwcalc = function(probs,eps = 1e-8) { 
  # twins and samesex instrument - use all mothers - 3 points of support
  # NOTE set for decreasing g function is empty!
  
  f00_0 = probs[1,1]; f01_0 = probs[1,2]; f10_0 = probs[1,3]; f11_0 = probs[1,4]
  f00_1 = probs[3,1]; f01_1 = probs[3,2]; f10_1 = probs[3,3]; f11_1 = probs[3,4]
  
  numtw1 = probs[2,7] + probs[4,7]
  
  f00_2 = (probs[2,1]*probs[2,7] + probs[4,1]*probs[4,7])/numtw1
  f01_2 = (probs[2,2]*probs[2,7] + probs[4,2]*probs[4,7])/numtw1
  f10_2 = (probs[2,3]*probs[2,7] + probs[4,3]*probs[4,7])/numtw1
  f11_2 = (probs[2,4]*probs[2,7] + probs[4,4]*probs[4,7])/numtw1
  
  incempty = FALSE
  inc_up_g0 = min(f00_0 + f01_0 , f00_1 + f01_1, f00_2 + f01_2)
  inc_lo_g0 = max(f00_0 , f00_1, f00_2)
  inc_up_g1 = min(1-f11_0 , 1-f11_1, 1-f11_2)
  inc_lo_g1 = max(f00_0 + f01_0 , f00_1 + f01_1, f00_2 + f01_2)
  if(inc_up_g0 < inc_lo_g0-eps || inc_up_g1 < inc_lo_g1-eps) {incempty = TRUE}
  
  decempty = FALSE
  dec_up_g0 = min(1 - f10_0 , 1 -  f10_1,  -  f10_2 )
  dec_lo_g0 = max(f00_0 + f01_0 , f00_1 + f01_1, f00_2 + f01_2)
  dec_up_g1 = min(f00_0 + f01_0 , f00_1 + f01_1, f00_2 + f01_2)
  dec_lo_g1 = max(f01_0 , f01_1, f01_2)
  if(dec_up_g0 < dec_lo_g0 -eps|| dec_up_g1 < dec_lo_g1-eps) {decempty = TRUE}
  
  
  inc = rbind(c(inc_up_g0,inc_lo_g0),c(inc_up_g1,inc_lo_g1))
  dec = rbind(c(dec_up_g0,dec_lo_g0),c(dec_up_g1,dec_lo_g1))
  
  inc_up_g0mg1 = inc[1,1] - inc[2,2]
  inc_lo_g0mg1 = inc[1,2] - inc[2,1]
  dec_up_g0mg1 = dec[1,1] - dec[2,2]
  dec_lo_g0mg1 = dec[1,2] - dec[2,1]
  
  
  inc_g0mg1 = c(inc_up_g0mg1,inc_lo_g0mg1)
  dec_g0mg1 = c(dec_up_g0mg1,dec_lo_g0mg1)
  
  if (incempty) {inc = NA; inc_g0mg1 = NA}
  if (decempty) {dec = NA; dec_g0mg1 = NA}
  
  return(list(inc = inc, dec = dec, inc_g0mg1= inc_g0mg1, dec_g0mg1 = dec_g0mg1 , incempty = incempty, decempty = decempty))
}

sstwresult = sstwcalc(probs80)

# Here is the function that draws the graph
# freshplot is FALSE if we are just adding elements to the graph

ssdraw = function(ssr,freshplot=T,col = NA,border = NA,lwd=2) {
  if (freshplot) {par(pty='s')
    plot(c(0,1),c(0,1),type = 'n',xlab = "g(0)",ylab = "g(1)")
    abline(0,1)
    abline(h=c(0,1),v=c(0,1),col = "grey")
  }
  if (!ssr$incempty) {
    polygon(x=c(rev(ssr$inc[1,]),ssr$inc[1,]),y=c(rep(ssr$inc[2,2],2),rep(ssr$inc[2,1],2)),col = col,border=border,lwd = lwd)
  }
  if (!ssr$decempty) {
    polygon(x=c(rev(ssr$dec[1,]),ssr$dec[1,]),y=c(rep(ssr$dec[2,2],2),rep(ssr$dec[2,1],2)),col = col,border = border,lwd = lwd)
  }
}

# Now create and save to eps file.

postscript(file = paste(writepath,"temp_binplot2.eps",sep = ''), horizontal = F,useKerning = F) # omit this line and just run the next 5 lines
                                                                                           # to see graph in RStudio

ssdraw(ssresult,col="lightblue",border = "blue",lwd=2)             # draw the axes etc and the same sex sets
ssdraw(twresult,freshplot=F,border = "red",lwd=5)                  # add the twins results
ssdraw(sstwresult,freshplot=F,border = "yellow",lwd=2)             # add the twins+samesex results
legend(x=0.8,y=0.25,fill = c("lightblue","red","yellow"),cex=1, bty = "n",
       legend = c("same-sex","twins","both"),title = "instruments")

dev.off(max(dev.list()))  # turns off the postscript driver at which point the file is closed and can be used


