# Analysis of Angrist Evans (1998) data for the Handbook chapter "Generalized Instrumental Variable Models, Methods, and Applications."
# This file just defines essential functions and does calculations
# using education of the mother > 12  as an additional explanatory variable
# with the same sex and then the twins instrument and with both.

# This file has code to draw Figures 9, 10, and 11 in the Handbook chapter.

# important to note that it is alpha > 0 where we expect to find non-empty sets using the twins instrument.
# there is only a violation in two cases and the violations are very small.

# define path to directories where files (graphics) will be written.

writepath = "/Users/amr331/Dropbox/GIV/Handbook/Replication Files/Section 8.2/" 
#writepath = "/Users/andrew/Dropbox/GIV/Handbook/Replication Files/Section 8.2/OUTPUT/" # Cambridge iMac

pums80 <- read.table("https://dataverse.harvard.edu/api/access/datafile/:persistentId?persistentId=doi:10.7910/DVN/8RYANI/HKEUEN",
                     sep="\t", header=TRUE)

# bounds_exog computes bounds at each integer year of age, "suped" and "infed" over the values of the binary same sex instrument
# at each value of the included exogenous variable which ranges from Lowexog to highexog
# b is for bound, p and m indicate plus and minus for effect of family size, 0 and 1 indicate value of family size indicator, u and l indicate upper and lower bounds.
# this can be called with other exogenous variables than age of mother.

bounds_exog = function(probs,lowexog = 21,highexog=35) {
  answer = matrix(0,nrow = highexog-lowexog+1,ncol=8)
  for (exogvalue in lowexog:highexog) {
    
    bp0u = min(probs[1,exogvalue-lowexog+1,1]+probs[2,exogvalue-lowexog+1,1],probs[1,exogvalue-lowexog+1,2]+probs[2,exogvalue-lowexog+1,2])
    bp0l = max(probs[1,exogvalue-lowexog+1,1],probs[1,exogvalue-lowexog+1,2])
    bp1u = min(1-probs[4,exogvalue-lowexog+1,1],1-probs[4,exogvalue-lowexog+1,2])
    bp1l = max(probs[1,exogvalue-lowexog+1,1]+probs[2,exogvalue-lowexog+1,1],probs[1,exogvalue-lowexog+1,2]+probs[2,exogvalue-lowexog+1,2])
    
    bm0u = min(1-probs[3,exogvalue-lowexog+1,1],1-probs[3,exogvalue-lowexog+1,2])
    bm0l = max(probs[1,exogvalue-lowexog+1,1]+probs[2,exogvalue-lowexog+1,1],probs[1,exogvalue-lowexog+1,2]+probs[2,exogvalue-lowexog+1,2])
    bm1u = min(probs[1,exogvalue-lowexog+1,1]+probs[2,exogvalue-lowexog+1,1],probs[1,exogvalue-lowexog+1,2]+probs[2,exogvalue-lowexog+1,2])
    bm1l = max(probs[2,exogvalue-lowexog+1,1],probs[2,exogvalue-lowexog+1,2])
    
    answer[exogvalue-lowexog+1,] = c(bp0u,bp0l,bp1u,bp1l,bm0u,bm0l,bm1u,bm1l)
    
  }
  return(answer)
}

# inset returns True or False indicating a value of the parameters is in or out of the identified set

inset = function(alpha,beta0,beta1,bounds,lowexog=21,highexog = 35) {
  inset = TRUE
  if (alpha >= 0) {addindex = 0} else {addindex = 4}
  for (exogvalue in (lowexog:highexog)) {
    thresholdvalue0 = pnorm(        beta0 + beta1 * exogvalue)
    thresholdvalue1 = pnorm(alpha + beta0 + beta1 * exogvalue)
    if ((bounds[exogvalue-lowexog+1,1+addindex] < thresholdvalue0) | (bounds[exogvalue-lowexog+1,2+addindex] > thresholdvalue0)
        | (bounds[exogvalue-lowexog+1,3+addindex] < thresholdvalue1) | (bounds[exogvalue-lowexog+1,4+addindex] > thresholdvalue1)) {inset = FALSE;break()}
  }
  return(list(inset = inset, parameters = c(alpha,beta0,beta1)))  
}

# create function measuring distance of a point from the set (positive off the set) to  give to optim to find a point in the id set

distfrset = function(x,bounds,lowexog=21,highexog=35) {
  alpha = x[1];beta0 = x[2];beta1 = x[3]
  answer = -Inf
  if (alpha >= 0) {addindex = 0} else {addindex = 4}
  for (exogvalue in (lowexog:highexog)) {
    thresholdvalue0 = pnorm(        beta0 + beta1 * exogvalue)
    thresholdvalue1 = pnorm(alpha + beta0 + beta1 * exogvalue)
    answer = max(answer, thresholdvalue0 - bounds[exogvalue-lowexog+1,1+addindex],
                 bounds[exogvalue-lowexog+1,2+addindex]-thresholdvalue0,
                 thresholdvalue1 - bounds[exogvalue-lowexog+1,3+addindex],
                 bounds[exogvalue-lowexog+1,4+addindex] - thresholdvalue1)
  }
  return(answer)  
}

# get id set membership over a grid of values of the 3 parameters

aegrid1 = function(avalues,b0values,b1values,bounds=bounds80_agess,lowexog = 21,highexog = 35) {
  answer = matrix(0,nrow = avalues[3]*b0values[3]*b1values[3],ncol = 4)
  count = 0
  for (alpha in seq(avalues[1],avalues[2],length = avalues[3])) {
    for (beta0 in seq(b0values[1],b0values[2],length = b0values[3])) {
      for (beta1 in seq(b1values[1],b1values[2],length = b1values[3])) {
        count = count + 1
        hold = inset(alpha,beta0,beta1,bounds,lowexog = lowexog,highexog = highexog)
        answer[count,] = c(hold$inset,alpha,beta0,beta1)
      }
    }
  }
  return(list(grid=answer,avalues=avalues,b0values=b0values,b1values=b1values))
}

# draw 2D projections of 3D set. "project" selects which 2 dimensions to project.

projectgrid = function(grid,project) {
  axislabs = c(expression(alpha),expression(beta[0]),expression(beta[1]))
  gridspec = rbind(grid$avalues,grid$b0values,grid$b1values)[project,1:2]
  plot(gridspec[1,],gridspec[2,],type = 'n',xlab = axislabs[project[1]],ylab = axislabs[project[2]])
  points(grid$grid[grid$grid[,1]==1,project+1],pch=18,col='blue',lwd=2)
}

# Draw the 2D projections as convex hulls.

projectconvgrid = function(grid,project,plotboundaries = NULL) {
  axislabs = c(expression(alpha),expression(beta[0]),expression(beta[1]))
  gridspec = rbind(grid$avalues,grid$b0values,grid$b1values)[project,1:2]
  if (is.null(plotboundaries)) {xval = gridspec[1]; yval = gridspec[2]} else {
    xval = plotboundaries[project[1],]
    yval = plotboundaries[project[2],]
  }
  plot(xval,yval,type = 'n',xlab = axislabs[project[1]],ylab = axislabs[project[2]])
  hold = grid$grid[grid$grid[,1]==1,project+1]
  alphapos = (1:nrow(hold))[grid$grid[grid$grid[,1]==1,2] > 0]
  alphaneg = (1:nrow(hold))[grid$grid[grid$grid[,1]==1,2] < 0]
  holdpos = hold[alphapos,]
  hpts = chull(holdpos)
  hpts = c(hpts,hpts[1])
  polygon(holdpos[hpts,],col = "lightblue",border = "blue",lwd = 2)
  holdneg = hold[alphaneg,]
  hpts = chull(holdneg)
  hpts = c(hpts,hpts[1])
  polygon(holdneg[hpts,],col = "lightblue",border = "blue",lwd = 2)
  abline(h=0,v=0,col="grey",lty=2,lwd=2)
}


################################### $$$$$ parametric probit model with education of the mother > 12  and SAME SEX instrument
# three way array, giving estimated probabilities of 
# (works, >2 chidren) = (0,0), (0,1), (1,0), (1,1) and number in cell (year of age * same sex instrument)
# by year of age and same sex instrument
# when using same sex instrument alone I exclude women with multiple 2nd birth events

fij_educgt12ss = function(pumsdata = pums80,lowage=0,highage = 1) {
  educgt12 = pums80$educm > 12
  answer = array(0,dim = c(5,highage-lowage+1,2))
  for (age in (lowage:highage)) {
    for (ss in (0:1)) {
      num = sum(pumsdata$samesex == ss & educgt12 == age & pumsdata$multi2nd == 0)
      answer[1,age - lowage + 1,ss+1] = sum(pumsdata$samesex == ss &  educgt12 == age & pumsdata$multi2nd == 0
                                            & pumsdata$workedm == 0 & pumsdata$morekids == 0)/num
      answer[2,age - lowage + 1,ss+1] = sum(pumsdata$samesex == ss &  educgt12 == age & pumsdata$multi2nd == 0
                                            & pumsdata$workedm == 0 & pumsdata$morekids == 1)/num
      answer[3,age - lowage + 1,ss+1] = sum(pumsdata$samesex == ss &  educgt12 == age & pumsdata$multi2nd == 0
                                            & pumsdata$workedm == 1 & pumsdata$morekids == 0)/num
      answer[4,age - lowage + 1,ss+1] = sum(pumsdata$samesex == ss &  educgt12 == age & pumsdata$multi2nd == 0
                                            & pumsdata$workedm == 1 & pumsdata$morekids == 1)/num
      answer[5,age - lowage + 1,ss+1] = num
    }
  }
  return(answer)
}

# calculate array of probabilities
probs80_educgt12ss = fij_educgt12ss()

# calculate upper and lower bounds for positive and negative coefficient (alpha) on family size (Y2) , for Y2 = 0 and Y2 = 1 
bounds80_educgt12ss = bounds_exog(probs80_educgt12ss,lowexog = 0, highexog = 1)

grideducgt12 = aegrid1(c(-1.5,2,70),c(-1,1,70),c(-0.6,0.5,70),bounds = bounds80_educgt12ss,lowexog = 0, highexog = 1)
grideducgt12_150 = aegrid1(c(-1.5,2,150),c(-1,1,150),c(-0.6,0.5,150),bounds = bounds80_educgt12ss,lowexog = 0, highexog = 1)
grideducgt12_250 = aegrid1(c(-1.5,1.6,250),c(-.75,.75,250),c(-0.6,0.5,250),bounds = bounds80_educgt12ss,lowexog = 0, highexog = 1)

# following pictures (until $$$$$$$$$) show MLEs, not drawn in Handbokk chapter

plotboundaries = rbind(c(-1.5,1.5),c(-1,1),c(-1,1))

par(pty='s',cex.lab=1.3)
projectconvgrid(grideducgt12_150,c(1,3),plotboundaries = plotboundaries)
lines(x=c(0.136683,0.5893403),y=c(-0.1514041,-0.1514041),col="red",lwd=4)  # projection of twins instrument only id set, alpha beta1
lines(x=c(0.151207,0.550469),y=c(-0.1514041,-0.1514041),col="yellow",lwd=2)  # projection of twins and ss instrument id set, alpha beta1
 points(x=0.295,y=-0.122,pch = 19,cex=.7,col="blue") # excludes twin birth mothers
 points(x=0.192,y=-0.131,pch = 19,cex=.7,col="red")
 points(x=0.236,y=-0.127,pch = 19,cex=.7,col="yellow")
 
legend("topleft",legend = c("same sex","twins","both"), bty="n",border = c("black","black","black"),
       fill = c("lightblue","red","yellow"),title = " Using as instruments:",cex=1,title.adj=0)

postscript(file = paste(writepath,"projbeta1alpha.eps",sep = ''), horizontal = F,useKerning = F)
par(pty='s')

par(cex.lab=1.3,mar=c(5, 6, 4, 2) + 0.1) # need extra left hand margin to fit in greek beta label
projectconvgrid(grideducgt12_150,c(1,3),plotboundaries = plotboundaries) # dens 150*150*150 grid
lines(x=c(0.136683,0.5893403),y=c(-0.1514041,-0.1514041),col="red",lwd=4)  # projection of twins instrument only id set, alpha beta1
lines(x=c(0.151207,0.550469),y=c(-0.1514041,-0.1514041),col="yellow",lwd=2)  # projection of twins and ss instrument id set, alpha beta1
points(x=0.295,y=-0.122,pch = 19,cex=.7,col="blue") # ss alone, excludes twin birth mothers
points(x=0.192,y=-0.131,pch = 19,cex=.7,col="red")  # twins alone
points(x=0.236,y=-0.127,pch = 19,cex=.7,col="yellow") # twins and ss

legend("topleft",legend = c("same sex","twins","both"), bty="n",border = c("black","black","black"),
       fill = c("lightblue","red","yellow"),title = " Using as instruments:",cex=1,title.adj=0)

dev.off(max(dev.list()))

# projections as calculated by Mathematica - they agree.
abline(h=c(-.5508,.3953,-.5472,.1801),v=c(.0287,1.4324,-1.07293,-0.02870),col="blue")
abline(v=c(.136683,.58934),col="red")
abline(v=c(.15120,.550649),col="yellow")
# $$$$$$$$$$$$$$$$$$$$$$$$$

# pictures drawn June 12th 2018 for handbook chapter - eliminating MLEs and additional projections. File names changed to avoid confusion

postscript(file = paste(writepath,"temp_projbeta1alphaJune12.eps",sep = ''), horizontal = F,useKerning = F) # FIGURE 9
par(pty='s')

par(cex.lab=1.3,mar=c(5, 6, 4, 2) + 0.1) # need extra left hand margin to fit in greek beta label
projectconvgrid(grideducgt12_250,c(1,3),plotboundaries = plotboundaries) # dens 150*150*150 grid
lines(x=c(0.136683,0.5893403),y=c(-0.1514041,-0.1514041),col="red",lwd=4)  # projection of twins instrument only id set, alpha beta1
lines(x=c(0.151207,0.550469),y=c(-0.1514041,-0.1514041),col="yellow",lwd=2)  # projection of twins and ss instrument id set, alpha beta1
#points(x=0.295,y=-0.122,pch = 19,cex=.7,col="blue") # ss alone, excludes twin birth mothers
#points(x=0.192,y=-0.131,pch = 19,cex=.7,col="red")  # twins alone
#points(x=0.236,y=-0.127,pch = 19,cex=.7,col="yellow") # twins and ss

legend("topleft",legend = c("same sex","twins","both"), bty="n",border = c("black","black","black"),
       fill = c("lightblue","red","yellow"),title = " Using as instruments:",cex=1,title.adj=0)

dev.off(max(dev.list()))

postscript(file = paste(writepath,"temp_projbeta0beta1June12.eps",sep = ''), horizontal = F,useKerning = F) # FIGURE 10
par(pty='s')

par(cex.lab=1.3,mar=c(5, 6, 4, 2) + 0.1) # need extra left hand margin to fit in greek beta label
projectconvgrid(grideducgt12_250,c(2,3),plotboundaries = plotboundaries) # dens 150*150*150 grid
lines(x=c(-0.47633,-0.023672),y=c(-0.1514041,-0.1514041),col="red",lwd=4)  # projection of twins instrument only id set, beta0 beta1
lines(x=c(-0.437638,-0.0381957),y=c(-0.1514041,-0.1514041),col="yellow",lwd=2)  # projection of twins and ss instrument id set, beta0 beta1
#points(x=0.295,y=-0.122,pch = 19,cex=.7,col="blue") # ss alone, excludes twin birth mothers
#points(x=0.192,y=-0.131,pch = 19,cex=.7,col="red")  # twins alone
#points(x=0.236,y=-0.127,pch = 19,cex=.7,col="yellow") # twins and ss

legend("topleft",legend = c("same sex","twins","both"), bty="n",border = c("black","black","black"),
       fill = c("lightblue","red","yellow"),title = " Using as instruments:",cex=1,title.adj=0)

dev.off(max(dev.list()))

postscript(file = paste(writepath,"temp_projbeta0alphaJune12.eps",sep = ''), horizontal = F,useKerning = F) # FIGURE 11
par(pty='s')

par(cex.lab=1.3,mar=c(5, 6, 4, 2) + 0.1) # need extra left hand margin to fit in greek beta label
projectconvgrid(grideducgt12_250,c(1,2),plotboundaries = plotboundaries) # dens 150*150*150 grid
lines(x=c(.58934,.136683),y=c(-.47633,-.0236721),col="red",lwd=4)  # projection of twins instrument only id set, beta0 alpha
lines(x=c(0.550649,0.151207),y=c(-.437638,-0.0381957),col="yellow",lwd=2)  # projection of twins and ss instrument id set, alpha beta1
#points(x=0.295,y=-0.122,pch = 19,cex=.7,col="blue") # ss alone, excludes twin birth mothers
#points(x=0.192,y=-0.131,pch = 19,cex=.7,col="red")  # twins alone
#points(x=0.236,y=-0.127,pch = 19,cex=.7,col="yellow") # twins and ss

legend("topleft",legend = c("same sex","twins","both"), bty="n",border = c("black","black","black"),
       fill = c("lightblue","red","yellow"),title = " Using as instruments:",cex=1,title.adj=0)

dev.off(max(dev.list()))