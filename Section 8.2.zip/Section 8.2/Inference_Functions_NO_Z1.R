# This file contains functions that compute moment inequalities implied by the IV binary outcome model studied in Section 8.2
# of the Handbook of Econometrics chapter  "Generalized Instrumental Variable Models, Methods, and Applications" by Andrew Chesher and Adam Rosen.

###### Function compute_g_upper_moments #####################################################
# This function computes the moment inequalities on g(0),g(1) in the set A upper (Delta <= 0).
# For the given value to be in the identified the moment functions must all be nonnegative
# The return values can be used to test the hypothesis that all these moment inequalities hold,
# for example using an intersection bounds test as described in Chernozhukov, Lee, and Rosen (2013)
# INPUT PARAMETERS
#   g: A fixed value for the 2-vector (g(0),g(1)) which the hypothesis (g(0),g(1)) = g is to be tested.
#   b: The estimate of the parameters that enter into the moment functions
#   svar_normalized_zeta_hat: a consistent estimator of the asymptotic variance of sqrt(n)*zeta_hat
# OUTPUT PARAMETERS (as a list)
#   moments: The value of the sample moments evaluated the input delta_value and zeta_hat
#   Sigma_hat: An estimator for the asymptotic variance of sqrt(n) times the sample moments computed 
#              by application of the delta method.
#####################################################################################################
compute_g_upper_moments <- function(g, b, svar_normalized_zeta_hat) {
  g0 <- g[1]
  g1 <- g[2]
  K <- length(b) # Number of parameters in zeta
  Sz <- K/6 # Support points of Z
  J <- 4*Sz # Number of moments
  moments <- rep(0,J)
  pn <- matrix(0, nrow = J, ncol = K)
  for (i in 1:Sz) {
    t <- (i-1)*6 # index for zeta parameter for iteration i
    row_idx <- (i-1)*4 + 1 # starting row index for iteration i
    col_idx <- t + 1 # starting column index for iteration i
    moments[row_idx:(i*4)] <- c(g0 - b[t+2]/b[t+1] , b[t+3]/b[t+1] - g0, g1 - b[t+3]/b[t+1], b[t+4]/b[t+1] - g1)
    pn[(row_idx:(i*4)),col_idx] <- c( b[t+2], -b[t+3], b[t+3], -b[t+4]) / (b[t+1]^2)
    pn[row_idx,(col_idx+1)] <- -1/b[t+1]
    pn[(row_idx+1),(col_idx+2)] <- 1/b[t+1]
    pn[(row_idx+2),(col_idx+2)] <- -1/b[t+1]
    pn[(row_idx+3),(col_idx+3)] <- 1/b[t+1]
  }
  
  Sigma_hat <- pn %*% svar_normalized_zeta_hat %*% t(pn)
  return( list(moments=moments, Sigma_hat=Sigma_hat) )
}
###### End of compute_g_upper_moments ###############################################################

###### Function compute_g_lower_moments #####################################################
# This function computes the moment inequalities on g(0),g(1) in the set A lower (Delta >= 0).
# For the given value to be in the identified the moment functions must all be nonnegative
# The return values can be used to test the hypothesis that all these moment inequalities hold,
# for example using an intersection bounds test as described in Chernozhukov, Lee, and Rosen (2013)
# INPUT PARAMETERS
#   g: A fixed value for the 2-vector (g(0),g(1)) which the hypothesis (g(0),g(1)) = g is to be tested.
#   b: The estimate of the parameters that enter into the moment functions
#   svar_normalized_zeta_hat: a consistent estimator of the asymptotic variance of sqrt(n)*zeta_hat
# OUTPUT PARAMETERS (as a list)
#   moments: The value of the sample moments evaluated the input delta_value and zeta_hat
#   Sigma_hat: An estimator for the asymptotic variance of sqrt(n) times the sample moments computed 
#              by application of the delta method.
#####################################################################################################
compute_g_lower_moments <- function(g, b, svar_normalized_zeta_hat) {
  g0 <- g[1]
  g1 <- g[2]
  K <- length(b) # Number of parameters zeta
  Sz <- K/6 # Support points of Z
  J <- 4*Sz # Number of moments
  moments <- rep(0,J)
  pn <- matrix(0, nrow = J, ncol = K)
  for (i in 1:Sz) {
    t <- (i-1)*6 # index for zeta parameter for iteration i
    row_idx <- (i-1)*4 + 1 # starting row index for iteration i
    col_idx <- t + 1 # starting column index for iteration i
    moments[row_idx:(i*4)] <- c(g0 - b[t+3]/b[t+1] , b[t+5]/b[t+1] - g0, g1 - b[t+6]/b[t+1], b[t+3]/b[t+1] - g1)
    pn[(row_idx:(i*4)),col_idx] <- c( b[t+3], -b[t+5], b[t+6], -b[t+3]) / (b[t+1]^2)
    pn[row_idx,(col_idx+2)] <- -1/b[t+1]
    pn[(row_idx+1),(col_idx+4)] <- 1/b[t+1]
    pn[(row_idx+2),(col_idx+5)] <- -1/b[t+1]
    pn[(row_idx+3),(col_idx+2)] <- 1/b[t+1]
  }
  
  Sigma_hat <- pn %*% svar_normalized_zeta_hat %*% t(pn)
  return( list(moments=moments, Sigma_hat=Sigma_hat) )
}
###### End of compute_g_lower_moments ###############################################################

################ Function compute_g0_moments_upper ###############################################
# This function computes the moment inequalities on g(0) in the set A upper (Delta <= 0).
# For the given value to be in the identified the moment functions must all be nonnegative
# The return values can be used to test the hypothesis that all these moment inequalities hold,
# for example using an intersection bounds test as described in Chernozhukov, Lee, and Rosen (2013)
# INPUT PARAMETERS
#   g0: A fixed value for which the hypothesis g(0) = g0 is to be tested.
#   b: The estimate of the parameters that enter into the moment functions
#   svar_normalized_zeta_hat: a consistent estimator of the asymptotic variance of sqrt(n)*zeta_hat
# OUTPUT PARAMETERS (as a list)
#   moments: The value of the sample moments evaluated the input delta_value and zeta_hat
#   Sigma_hat: An estimator for the asymptotic variance of sqrt(n) times the sample moments computed 
#              by application of the delta method.
#####################################################################################################
compute_g0_moments_upper <- function(g0, b, svar_normalized_zeta_hat) {
  K <- length(b) # Number of parameters in zeta
  Sz <- K/6 # Support points of Z
  J <- Sz * (Sz+1) # Number of moments
  moments <- rep(0,J)
  pn <- matrix(0, nrow = J, ncol = K)
  for (i in 1:Sz) { # Populate moments involving g0 and corresponding derivatives
    t <- (i-1)*6 # index for zeta parameter for iteration i
    row_idx <- (i-1)*(Sz+1) + 1 # starting row index for iteration i
    col_idx <- t + 1 # starting column index for iteration i
    moments[row_idx:(row_idx+1)] <- c(g0 - b[t+2]/b[t+1] , b[t+3]/b[t+1] - g0)
    pn[(row_idx:(row_idx+1)),col_idx] <- c( b[t+2], -b[t+3]) / (b[t+1]^2)
    pn[row_idx,(col_idx+1)] <- -1/b[t+1]
    pn[(row_idx+1),(col_idx+2)] <- 1/b[t+1]
    row_idx <- row_idx + 1 # Note the above handles the first two rows, so an increment by one here is needed.
    for (j in 1:Sz) {
      if (i != j) { # The inequalities for rows i==j (k==l) are automatically satisfied
        row_idx <- row_idx + 1
        s <- (j-1) * 6
        moments[row_idx] <- b[t+4] / b[t+1] - b[s+3] / b[s+1]
        pn[row_idx,t+1] <- - b[t+4] / (b[t+1]^2)
        pn[row_idx,t+4] <- 1/b[t+1]
        pn[row_idx,s+3] <- - 1/b[s+1]
        pn[row_idx,s+1] <- b[s+3] / (b[s+1]^2)
      }
    }
  }
  Sigma_hat <- pn %*% svar_normalized_zeta_hat %*% t(pn)
  return( list(moments=moments, Sigma_hat=Sigma_hat) )
}
###### End of compute_g0_moments_upper ###############################################################

################ Function compute_g0_moments_lower ###############################################
# This function computes the moment inequalities on g(0) in the set A lower (Delta >= 0).
# For the given value to be in the identified the moment functions must all be nonnegative
# The return values can be used to test the hypothesis that all these moment inequalities hold,
# for example using an intersection bounds test as described in Chernozhukov, Lee, and Rosen (2013)
# INPUT PARAMETERS
#   g0: A fixed value for which the hypothesis g(0) = g0 is to be tested.
#   b: The estimate of the parameters that enter into the moment functions
#   svar_normalized_zeta_hat: a consistent estimator of the asymptotic variance of sqrt(n)*zeta_hat
# OUTPUT PARAMETERS (as a list)
#   moments: The value of the sample moments evaluated the input delta_value and zeta_hat
#   Sigma_hat: An estimator for the asymptotic variance of sqrt(n) times the sample moments computed 
#              by application of the delta method.
#####################################################################################################
compute_g0_moments_lower <- function(g0, b, svar_normalized_zeta_hat) {
  K <- length(b) # Number of parameters in zeta
  Sz <- K/6 # Support points of Z
  J <- Sz * (Sz+1) # Number of moments
  moments <- rep(0,J)
  pn <- matrix(0, nrow = J, ncol = K)
  for (i in 1:Sz) { # Populate moments involving g0 and corresponding derivatives
    t <- (i-1)*6 # index for zeta parameter for iteration i
    row_idx <- (i-1)*(Sz+1) + 1 # starting row index for iteration i
    col_idx <- t + 1 # starting column index for iteration i
    moments[row_idx:(row_idx+1)] <- c(g0 - b[t+3]/b[t+1] , b[t+5]/b[t+1] - g0)
    pn[(row_idx:(row_idx+1)),col_idx] <- c( b[t+3], -b[t+5]) / (b[t+1]^2)
    pn[row_idx,(col_idx+2)] <- -1/b[t+1]
    pn[(row_idx+1),(col_idx+4)] <- 1/b[t+1]
    row_idx <- row_idx + 1 # Note the above handles the first two rows, so an increment by one here is needed.
    for (j in 1:Sz) {
      if (i != j) { # The inequalities for rows i==j (k==l) are automatically satisfied
        row_idx = row_idx + 1
        s <- (j-1) * 6
        moments[row_idx] <- b[t+3] / b[t+1] - b[s+6] / b[s+1]
        pn[row_idx,t+1] <- - b[t+3] / (b[t+1]^2)
        pn[row_idx,t+3] <- 1/b[t+1]
        pn[row_idx,s+6] <- -1/b[s+1]
        pn[row_idx,s+1] <- b[s+6] / (b[s+1]^2)
      }
    }
  }
  Sigma_hat <- pn %*% svar_normalized_zeta_hat %*% t(pn)
  return( list(moments=moments, Sigma_hat=Sigma_hat) )
}
###### End of compute_g0_moments_lower ###############################################################

################ Function compute_g1_moments_upper ###############################################
# This function computes the moment inequalities on g(1) in the set A upper (Delta <= 0).
# For the given value to be in the identified the moment functions must all be nonnegative
# The return values can be used to test the hypothesis that all these moment inequalities hold,
# for example using an intersection bounds test as described in Chernozhukov, Lee, and Rosen (2013)
# INPUT PARAMETERS
#   g1: A fixed value for which the hypothesis g(1) = g1 is to be tested.
#   b: The estimate of the parameters that enter into the moment functions
#   svar_normalized_zeta_hat: a consistent estimator of the asymptotic variance of sqrt(n)*zeta_hat
# OUTPUT PARAMETERS (as a list)
#   moments: The value of the sample moments evaluated the input delta_value and zeta_hat
#   Sigma_hat: An estimator for the asymptotic variance of sqrt(n) times the sample moments computed 
#              by application of the delta method.
#####################################################################################################
compute_g1_moments_upper <- function(g1, b, svar_normalized_zeta_hat) {
  K <- length(b) # Number of parameters in zeta
  Sz <- K/6 # Support points of Z
  J <- Sz * (2+Sz-1) # Number of moments
  moments <- rep(0,J)
  pn <- matrix(0, nrow = J, ncol = K)
  for (i in 1:Sz) { # Populate moments involving g0 and corresponding derivatives
    t <- (i-1)*6 # index for zeta parameter for iteration i
    row_idx <- (i-1)*(2+Sz-1) + 1 # starting row index for iteration i
    col_idx <- t + 1 # starting column index for iteration i
    moments[row_idx:(row_idx+1)] <- c(g1 - b[t+3]/b[t+1] , b[t+4]/b[t+1] - g1)
    pn[(row_idx:(row_idx+1)),col_idx] <- c( b[t+3], -b[t+4]) / (b[t+1]^2)
    pn[row_idx,(col_idx+2)] <- -1/b[t+1]
    pn[(row_idx+1),(col_idx+3)] <- 1/b[t+1]
    row_idx <- row_idx + 1 # Note the above handles the first two rows, so an increment by one here is needed.
    for (j in 1:Sz) {
      if (i != j) { # The inequalities for rows i==j (k==l) are automatically satisfied
        row_idx <- row_idx + 1
        s <- (j-1) * 6
        moments[row_idx] <- b[t+3] / b[t+1] - b[s+2] / b[s+1]
        pn[row_idx,t+1] <- - b[t+3] / (b[t+1]^2)
        pn[row_idx,t+3] <- 1/b[t+1]
        pn[row_idx,s+2] <- - 1/b[s+1]
        pn[row_idx,s+1] <- b[s+2] / (b[s+1]^2)
      }
    }
  }
  Sigma_hat <- pn %*% svar_normalized_zeta_hat %*% t(pn)
  return( list(moments=moments, Sigma_hat=Sigma_hat) )
}
###### End of compute_g1_moments_upper ###############################################################

################ Function compute_g1_moments_lower ###############################################
# This function computes the moment inequalities on g(1) in the set A lower (Delta >= 0).
# For the given value to be in the identified the moment functions must all be nonnegative
# The return values can be used to test the hypothesis that all these moment inequalities hold,
# for example using an intersection bounds test as described in Chernozhukov, Lee, and Rosen (2013)
# INPUT PARAMETERS
#   g1: A fixed value for which the hypothesis g(1) = g1 is to be tested.
#   b: The estimate of the parameters that enter into the moment functions
#   svar_normalized_zeta_hat: a consistent estimator of the asymptotic variance of sqrt(n)*zeta_hat
# OUTPUT PARAMETERS (as a list)
#   moments: The value of the sample moments evaluated the input delta_value and zeta_hat
#   Sigma_hat: An estimator for the asymptotic variance of sqrt(n) times the sample moments computed 
#              by application of the delta method.
#####################################################################################################
compute_g1_moments_lower <- function(g1, b, svar_normalized_zeta_hat) {
  K <- length(b) # Number of parameters in zeta
  Sz <- K/6 # Support points of Z
  J <- Sz * (2+Sz-1) # Number of moments
  moments <- rep(0,J)
  pn <- matrix(0, nrow = J, ncol = K)
  for (i in 1:Sz) { # Populate moments involving g0 and corresponding derivatives
    t <- (i-1)*6 # index for zeta parameter for iteration i
    row_idx <- (i-1)*(2+Sz-1) + 1 # starting row index for iteration i
    col_idx <- t + 1 # starting column index for iteration i
    moments[row_idx:(row_idx+1)] <- c(g1 - b[t+6]/b[t+1] , b[t+3]/b[t+1] - g1)
    pn[(row_idx:(row_idx+1)),col_idx] <- c( b[t+6], -b[t+1]) / (b[t+1]^2)
    pn[row_idx,(col_idx+5)] <- -1/b[t+1]
    pn[(row_idx+1),(col_idx+2)] <- 1/b[t+1]
    row_idx <- row_idx + 1 # Note the above handles the first two rows, so an increment by one here is needed.
    for (j in 1:Sz) {
      if (i != j) { # The inequalities for rows i==j (k==l) are automatically satisfied
        row_idx <- row_idx + 1
        s <- (j-1) * 6
        moments[row_idx] <- b[t+5] / b[t+1] - b[s+3] / b[s+1]
        pn[row_idx,t+1] <- - b[t+5] / (b[t+1]^2)
        pn[row_idx,t+5] <- 1/b[t+1]
        pn[row_idx,s+3] <- - 1/b[s+1]
        pn[row_idx,s+1] <- b[s+3] / (b[s+1]^2)
      }
    }
  }
  Sigma_hat <- pn %*% svar_normalized_zeta_hat %*% t(pn)
  return( list(moments=moments, Sigma_hat=Sigma_hat) )
}
###### End of compute_g1_moments_lower ###############################################################


################ Function compute_delta_moments_upper ###############################################
# This function computes the moment inequalities on Delta = g(0)-g(1) in the set A upper (Delta <= 0).
# For the given value to be in the identified the moment functions must all be nonnegative
# The return values can be used to test the hypothesis that all these moment inequalities hold,
# for example using an intersection bounds test as described in Chernozhukov, Lee, and Rosen (2013)
# INPUT PARAMETERS
#   dv: A fixed value for which the hypothesis Delta = dv is to be tested.
#   alpha: The asymptotic size of the test
#   b: The estimate of the parameters that enter into the moment functions
#   svar_normalized_zeta_hat: a consistent estimator of the asymptotic variance of sqrt(n)*zeta_hat
# OUTPUT PARAMETERS (as a list)
#   moments: The value of the sample moments evaluated the input delta_value and zeta_hat
#   Sigma_hat: An estimator for the asymptotic variance of sqrt(n) times the sample moments computed 
#              by application of the delta method.
#####################################################################################################
compute_delta_moments_upper <- function(dv, b, svar_normalized_zeta_hat) {
  K <- length(b) # Number of parameters in zeta
  Sz <- K/6 # Support points of Z
  J <- Sz * (4*Sz-3) # Number of moments
  moments <- rep(0,J)
  pn <- matrix(0, nrow = J, ncol = K)
  for (i in 1:Sz) { # Populate moments involving g0 and corresponding derivatives
    t <- (i-1)*6 # index for zeta parameter for iteration i
    row_idx <- (i-1)*(4*Sz-3) # starting row index for iteration i
    col_idx <- t + 1 # starting column index for iteration i
    for (j in 1:Sz) {
      s <- (j-1) * 6
      if (i != j) { # Then the this inequality is automatically satisfied for dv <= 0.
        row_idx <- row_idx + 1
        moments[row_idx] <- b[t+3] / b[t+1] - b[s+3] / b[s+1] - dv
        pn[row_idx,c(t+1,t+3,s+3,s+1)] <- c(-b[t+3]/(b[t+1]^2), 1/b[t+1], -1/b[s+1], b[s+3]/(b[s+1]^2))
      }
      row_idx <- row_idx + 1
      moments[row_idx] <- dv - b[t+2] / b[t+1] + b[s+4] / b[s+1]
      pn[row_idx,c(t+1,t+2,s+4,s+1)] <- c(b[t+2]/(b[t+1]^2), -1/b[t+1], 1/b[s+1], -b[s+4]/(b[s+1]^2))
      if (i != j) { # Then the last two of the four inequalities for each i,j are automatically satisfied
        row_idx <- row_idx + 1
        moments[row_idx] <- b[t+3] / b[t+1] - b[s+2] / b[s+1]
        pn[row_idx,c(t+1,t+3,s+2,s+1)] <- c(-b[t+3]/(b[t+1]^2), 1/b[t+1], -1/b[s+1], b[s+2]/(b[s+1]^2))
        row_idx <- row_idx + 1
        moments[row_idx] <- b[t+4] / b[t+1] - b[s+3] / b[s+1]
        pn[row_idx,c(t+1,t+4,s+3,s+1)] <- c(-b[t+4]/(b[t+1]^2), 1/b[t+1], -1/b[s+1], b[s+3]/(b[s+1]^2))
      }
    }
  }
  Sigma_hat <- pn %*% svar_normalized_zeta_hat %*% t(pn)
  return( list(moments=moments, Sigma_hat=Sigma_hat) )
}

################ Function compute_delta_moments_lower ###############################################
# This function computes the moment inequalities on Delta = g(0)-g(1) in the set A lower (Delta >= 0).
# For the given value to be in the identified the moment functions must all be nonnegative
# The return values can be used to test the hypothesis that all these moment inequalities hold,
# for example using an intersection bounds test as described in Chernozhukov, Lee, and Rosen (2013)
# INPUT PARAMETERS
#   dv: A fixed value for which the hypothesis Delta = dv is to be tested.
#   alpha: The asymptotic size of the test
#   b: The estimate of the parameters that enter into the moment functions
#   svar_normalized_zeta_hat: a consistent estimator of the asymptotic variance of sqrt(n)*zeta_hat
# OUTPUT PARAMETERS (as a list)
#   moments: The value of the sample moments evaluated the input delta_value and zeta_hat
#   Sigma_hat: An estimator for the asymptotic variance of sqrt(n) times the sample moments computed 
#              by application of the delta method.
#####################################################################################################
compute_delta_moments_lower <- function(dv, b, svar_normalized_zeta_hat) {
  K <- length(b) # Number of parameters in zeta
  Sz <- K/6 # Support points of Z
  J <- Sz * (4*Sz-3) # Number of moments
  moments <- rep(0,J)
  pn <- matrix(0, nrow = J, ncol = K)
  for (i in 1:Sz) { # Populate moments involving g0 and corresponding derivatives
    t <- (i-1)*6 # index for zeta parameter for iteration i
    row_idx <- (i-1)*(4*Sz-3) # starting row index for iteration i
    col_idx <- t + 1 # starting column index for iteration i
    for (j in 1:Sz) {
      s <- (j-1) * 6
      row_idx <- row_idx + 1
      moments[row_idx] <- b[t+5] / b[t+1] - b[s+6] / b[s+1] - dv
      pn[row_idx,c(t+1,t+5,s+6,s+1)] <- c(-b[t+5]/(b[t+1]^2), 1/b[t+1], -1/b[s+1], b[s+6]/(b[s+1]^2))
      if (i != j) { # Then the last three of the four inequalities for each i,j are automatically satisfied
        row_idx <- row_idx + 1
        moments[row_idx] <- dv - b[t+3] / b[t+1] + b[s+3] / b[s+1]
        pn[row_idx,c(t+1,t+3,s+3,s+1)] <- c(b[t+3]/(b[t+1]^2), -1/b[t+1], 1/b[s+1], -b[s+3]/(b[s+1]^2))
        row_idx <- row_idx + 1
        moments[row_idx] <- b[t+5] / b[t+1] - b[s+3] / b[s+1]
        pn[row_idx,c(t+1,t+5,s+3,s+1)] <- c(-b[t+5]/(b[t+1]^2), 1/b[t+1], -1/b[s+1], b[s+3]/(b[s+1]^2))
        row_idx <- row_idx + 1
        moments[row_idx] <- b[t+3] / b[t+1] - b[s+6] / b[s+1]
        pn[row_idx,c(t+1,t+3,s+6,s+1)] <- c(-b[t+3]/(b[t+1]^2), 1/b[t+1], -1/b[s+1], b[s+6]/(b[s+1]^2))
      }
    }
  }
  Sigma_hat <- pn %*% svar_normalized_zeta_hat %*% t(pn)
  return( list(moments=moments, Sigma_hat=Sigma_hat) )
}

################ Function compute_upper_set_test_moments ###############################################
# This function computes the moment inequalities that are necessary and sufficient for the set A upper to be nonempty.
# If the set is nonempty, then all of the moments computed will be nonnegative.
# The return values can be used to test the hypothesis that all these moment inequalities hold,
# for example using an intersection bounds test as described in Chernozhukov, Lee, and Rosen (2013)
# INPUT PARAMETERS
#   b: The estimate of the parameters that enter into the moment functions
#   svar_normalized_zeta_hat: a consistent estimator of the asymptotic variance of sqrt(n)*zeta_hat
# OUTPUT PARAMETERS (as a list)
#   moments: The value of the sampel moments evaluated the input delta_value and zeta_hat
#   Sigma_hat: An estimator for the asymptotic variance of sqrt(n) times the sample moments computed 
#              by application of the delta method.
#####################################################################################################
compute_upper_set_test_moments <- function(b, svar_normalized_zeta_hat) {
  K <- length(b) # Number of parameters in zeta
  Sz <- K/6 # Support points of Z
  J <- Sz * 2 * (Sz - 1) # Number of moments
  moments <- rep(0,J)
  pn <- matrix(0, nrow = J, ncol = K)
  for (i in 1:Sz) { # Populate moments involving g0 and corresponding derivatives
    t <- (i-1)*6 # index for zeta parameter for iteration i
    row_idx <- (i-1)*2*(Sz-1) # starting row index for iteration i
    col_idx <- t + 1 # starting column index for iteration i
    for (j in 1:Sz) {
      s <- (j-1) * 6
      if (i != j) { # If i==j then the inequalities are automatically satisfied
        row_idx <- row_idx + 1
        moments[row_idx] <- b[t+3] / b[t+1] - b[s+2] / b[s+1]
        pn[row_idx,c(t+1,t+3,s+2,s+1)] <- c(-b[t+3]/(b[t+1]^2), 1/b[t+1], -1/b[s+1], b[s+2]/(b[s+1]^2))
        row_idx <- row_idx + 1
        moments[row_idx] <- b[t+4] / b[t+1] - b[s+3] / b[s+1]
        pn[row_idx,c(t+1,t+4,s+3,s+1)] <- c(-b[t+4]/(b[t+1]^2), 1/b[t+1], -1/b[s+1], b[s+3]/(b[s+1]^2))
      }
    }
  }
  Sigma_hat <- pn %*% svar_normalized_zeta_hat %*% t(pn)
  return( list(moments=moments, Sigma_hat=Sigma_hat) )
}

################ Function compute_lower_set_test_moments ###############################################
# This function computes the moment inequalities that are necessary and sufficient for the set A lower to be nonempty.
# If the set is nonempty, then all of the moments computed will be nonnegative.
# The return values can be used to test the hypothesis that all these moment inequalities hold,
# for example using an intersection bounds test as described in Chernozhukov, Lee, and Rosen (2013)
# INPUT PARAMETERS
#   b: The estimate of the parameters that enter into the moment functions
#   svar_normalized_zeta_hat: a consistent estimator of the asymptotic variance of sqrt(n)*zeta_hat
# OUTPUT PARAMETERS (as a list)
#   moments: The value of the sampel moments evaluated the input delta_value and zeta_hat
#   Sigma_hat: An estimator for the asymptotic variance of sqrt(n) times the sample moments computed 
#              by application of the delta method.
#####################################################################################################
compute_lower_set_test_moments <- function(b, svar_normalized_zeta_hat) {
  K <- length(b) # Number of parameters in zeta
  Sz <- K/6 # Support points of Z
  J <- Sz * 2 * (Sz - 1) # Number of moments
  moments <- rep(0,J)
  pn <- matrix(0, nrow = J, ncol = K)
  for (i in 1:Sz) { # Populate moments involving g0 and corresponding derivatives
    t <- (i-1)*6 # index for zeta parameter for iteration i
    row_idx <- (i-1)*2*(Sz-1) # starting row index for iteration i
    col_idx <- t + 1 # starting column index for iteration i
    for (j in 1:Sz) {
      s <- (j-1) * 6
      if (i != j) { # If i==j then the inequalities are automatically satisfied
        row_idx <- row_idx + 1
        moments[row_idx] <- b[t+5] / b[t+1] - b[s+3] / b[s+1]
        pn[row_idx,c(t+1,t+5,s+3,s+1)] <- c(-b[t+5]/(b[t+1]^2), 1/b[t+1], -1/b[s+1], b[s+3]/(b[s+1]^2))
        row_idx <- row_idx + 1
        moments[row_idx] <- b[t+3] / b[t+1] - b[s+6] / b[s+1]
        pn[row_idx,c(t+1,t+3,s+6,s+1)] <- c(-b[t+3]/(b[t+1]^2), 1/b[t+1], -1/b[s+1], b[s+6]/(b[s+1]^2))
      }
    }
  }
  Sigma_hat <- pn %*% svar_normalized_zeta_hat %*% t(pn)
  return( list(moments=moments, Sigma_hat=Sigma_hat) )
}
