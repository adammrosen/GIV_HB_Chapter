################ Function Collect_CS_points ###############################################
# This function computes a grid of points in a 1-alpha level confidence set for 
# (g(0),g(1)) using an intersection bounds test as described in Chernozhukov, Lee, and Rosen (2013)
# INPUT PARAMETERS
#   alpha: The asymptotic size of the test used to collect points
#   instrument_case: "SS", "T", or other for both.
#   pums80: The data from AE98.
# OUTPUT PARAMETERS
#   pts: A 2 column matrix of points in which each row represents a (g0,g1) pair that is not
#        rejected by an alpha level intersection bounds test.
#####################################################################################################
Collect_CS_points <- function(alpha, instrument_case, pums80) {
  
  
  pums80 <- read.table("https://dataverse.harvard.edu/api/access/datafile/:persistentId?persistentId=doi:10.7910/DVN/8RYANI/HKEUEN",
                       sep="\t", header=TRUE)
  
  ### CREATE VARIABLES ###
  Y1 <- pums80$workedm
  Y2 <- pums80$morekids
  Z2 <- pums80$samesex
  Z3 <- pums80$multi2nd
  N <- length(Y1)
  #########################
  
  if (instrument_case == "SS") { # Use same sex instrument
    ####### SAME SEX INSTRUMENT - Remove observations with twins ############
    idx <- (Z3 == 0)
    Y1 <- Y1[idx]
    Y2 <- Y2[idx]
    Zmatrix <- matrix(Z2[idx], ncol=1)
    N = length(Y1)
    ##########################################
  }
  else if (instrument_case == "T") { # Use twins instrument
    Zmatrix <- matrix(Z3, ncol=1)
  }
  else { # Use both twins and same sex instruments
    Zmatrix <- matrix((1-Z3)*Z2 + 2*Z3, nrow=N, ncol=1)
  }
  
  ####### Create variable for support of Y and indicators for certain realizations need for forming conditional moments ####
  Ysupport <- rbind(c(0,0),c(0,1),c(1,0),c(1,1))
  Yindicators <- cbind((Y1==0) & (Y2==0), (Y1==0) & (Y2==1), !((Y1==1) & (Y2==0)), !((Y1==1) & (Y2==1)), (Y1==0))
  Yindicators_zeta <- cbind(1,Yindicators[,c(1,5,4,3,2)]) # rearrange rows into order used in defining components of zeta_hat
  # indicators for (0,0),(0,1),!(1,0),!(1,1),(0,.)
  ############################################################################################################
  
  ################ SAME SEX INSTRUMENT #####################
  Zsupport <- as.matrix(unique(Zmatrix))
  Zsupport <- as.matrix(Zsupport[order(Zsupport)])
  nSupportZ <- dim(Zsupport)[1]
  Zsupport_indices <- matrix(0,nrow=N,ncol=1) # This N*1 matrix indicates which of the ordered support
  # points correspond to observation i.
  # Generate unique numerical indices for each point of support
  for(i in 1:N) {
    Zsupport_indices[i,1] <- row.match(Zmatrix[i,],Zsupport)
  }
  #################################################################################################
  
  ################ Create indicators for binning of conditioning variables #############################
  Z_indicators = matrix(0,nrow=N,ncol=nSupportZ)
  for (i in 1:nSupportZ) {
    Z_indicators[,i] = (Zsupport_indices == i)
  }
  ###########################################################################################################
  
  ##### Estimate Sample Moments for Parametric Treatment of Moment Functions ######################
  zeta_indicators <- matrix(0, nrow=N, ncol = 6*nSupportZ)
  for (j in 0:(nSupportZ-1)) {
    zeta_idx <- j * 6 + 1
    zeta_indicators[,zeta_idx:(zeta_idx + 5)] = matrix((Zsupport_indices == (j+1)), nrow=N, ncol=6) * Yindicators_zeta
  }
  
  zeta_hat <- colMeans(zeta_indicators)
  svar_normalized_zeta_hat <- var(zeta_indicators)
  arglist <- list(zeta_hat=zeta_hat, svar_normalized_zeta_hat = svar_normalized_zeta_hat, N=N)
  ###################################################################################################
  
  ######## Function CLR_Test_gval ###################################################################
  # This functions computes the moments needed to test whether g0 or g1 are in the identified set
  # and then calls CLR_Test to test whether or not the moment inequalities that define the identified
  # set for the corresponding parameter.
  ###################################################################################################
  CLR_Test_gval <- function(g,alpha=0.05,arglist) {
    ifelse (g[1] < g[2], 
            result <- compute_g_upper_moments(g=g, b=arglist$zeta_hat, svar_normalized_zeta_hat = arglist$svar_normalized_zeta_hat),
            result <- compute_g_lower_moments(g=g, b=arglist$zeta_hat, svar_normalized_zeta_hat = arglist$svar_normalized_zeta_hat))
    return(CLR_Test(moment_estimates = result$moments, V = result$Sigma_hat/N, N = arglist$N, alpha = alpha)$pcorrected_min)
  }
  
  stepsize = 0.001
  # Collect point with g(0) <= g(1)
  g0_LB <- 0.15
  g0_UB <- 0.6
  g1_LB <- 0.35
  g1_UB <- 0.95
  g0_grid <- seq(g0_LB,g0_UB,stepsize)
  g1_grid <- seq(g1_LB,g1_UB,stepsize)
  g_set_matrix <- matrix(0, nrow=length(g0_grid)*length(g1_grid), ncol=3)
  i=0
  for (g0 in g0_grid) {
    cat("Checking (g0,g1) values with g0 = ", g0, "\n", sep="")
    search.time <- system.time(
      for (g1 in g1_grid) {
        if (g1>=g0) {
          i = i + 1
          result <- CLR_Test_gval(c(g0,g1),alpha,arglist)
          g_set_matrix[i,] <- c(g0,g1,result)
        }
      })
    cat("Checking (g0,g1) values with g0 = ", g0, "completed in ", search.time[3], " seconds.\n")
  }
  
  # Check removing last two inequalities.
  # g_in_set <- which((g_set_matrix[,3] >= 0) & (g_set_matrix[,1] != 0) & (g_set_matrix[,2] != 0))
  g_in_set <- which(g_set_matrix[,3] >= 0)
  pts <- cbind(g_set_matrix[g_in_set,1],g_set_matrix[g_in_set,2])
  
  # Collect points with g(0) >= g(1)
  g0_LB <- 0.4
  g0_UB <- 0.8
  g1_LB <- 0.15
  g1_UB <- 0.55
  g0_grid <- seq(g0_LB,g0_UB,stepsize)
  g1_grid <- seq(g1_LB,g1_UB,stepsize)
  g_set_matrix <- matrix(0, nrow=length(g0_grid)*length(g1_grid), ncol=3)
  i=0
  for (g0 in g0_grid) {
    cat("Checking (g0,g1) values with g0 = ", g0, "\n", sep="")
    search.time <- system.time(
      for (g1 in g1_grid) {
        if (g1<=g0) {
          i = i + 1
          result <- CLR_Test_gval(c(g0,g1),alpha,arglist)
          g_set_matrix[i,] <- c(g0,g1,result)
        }
      })
    cat("Checking (g0,g1) values with g0 = ", g0, "completed in ", search.time[3], " seconds.\n")
  }
  
  g_in_set <- which((g_set_matrix[,3] >= 0) & (g_set_matrix[,1] != 0) & (g_set_matrix[,2] != 0))
  pts <- rbind(pts,cbind(g_set_matrix[g_in_set,1],g_set_matrix[g_in_set,2]))
  
  return(pts)
}