# Analysis of Angrist Evans (1998) data for the Handbook chapter "Generalized Instrumental Variable Models, Methods, and Applications."
# This file does calculations with the same sex and then the twins instrument
# when there are no included exogenous variables. 95% confidence sets are constructed
# and plotted for the threshold parameters g(0) and g(1).

rm(list=ls())

if (!require("prodlim")) install.packages("prodlim") # for row.match function
library(prodlim)
if (!require("mvtnorm")) install.packages("mvtnorm") # for rmvnorm function
library(mvtnorm)
if (!require("ggplot2")) install.packages("ggplot2") # for plotting functions
library(ggplot2)

# CHANGE PATH VARIABLES TO POINT TO THE FOLDER WHERE THE SOURCE AND DATA FILES ARE STORED
replication_files_folder <- "/Users/amr93/Dropbox/GIV/Handbook/Replication Files/" # Set as approriate for local directory structure
path <- paste(replication_files_folder, "Section 8.2/", sep="")
setwd(path)

source("Inference_Functions_NO_Z1.R")
source("CLR_Functions.R")
source("Plot_Helper_Functions.R")

pums80 <- read.table("https://dataverse.harvard.edu/api/access/datafile/:persistentId?persistentId=doi:10.7910/DVN/8RYANI/HKEUEN",
                     sep="\t", header=TRUE)

SSpts <- Collect_CS_points(alpha = 0.05, instrument_case = "SS", pums80 = pums80)
Tpts <- Collect_CS_points(alpha = 0.05, instrument_case = "T", pums80 = pums80)
SSTpts <- Collect_CS_points(alpha = 0.05, instrument_case = "SST", pums80 = pums80)

SSptsdframe <- data.frame(SSpts, c='Same Sex')
Tptsdframe <- data.frame(Tpts, c='Twins')
SSTptsdframe <- data.frame(SSTpts, c='SST')
dat <- rbind(SSptsdframe, Tptsdframe, SSTptsdframe)

CSplot <- ggplot(dat, aes(X1, X2)) +
  geom_point(shape=46, size=0.001, aes(color=c)) +
  scale_colour_manual(name = 'Instruments:', values = c('Same Sex'='deepskyblue1', 'Twins'='red', 'SST'='yellow'), guide='legend')+
  guides(colour = guide_legend(override.aes = list(size=c(5,5,5), shape=c(19,19,19)))) + 
  theme_minimal() + # minimalistic theme with no background annotations
  geom_abline(intercept = 0, slope = 1, color = "chartreuse1", linetype=8) + # draw the green y=x line in the graph
  scale_x_continuous(name="g(0)", limits = c(0,1), breaks = c(0,0.2,0.4,0.6,0.8,1)) +
  scale_y_continuous(name="g(1)", limits = c(0,1), breaks = c(0,0.2,0.4,0.6,0.8,1)) # scale the x and y axes

CSplot

# Plot can now be saved to file if desired.